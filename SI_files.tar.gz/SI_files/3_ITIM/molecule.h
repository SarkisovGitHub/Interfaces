/***************************************************************************
                          molecule.h  - molecule definitions
                             -------------------
    begin                : Fri Aug 10 2001
    copyright            : (C) 2001 by Daniel dos Santos
    email                : dos.santos.daniel@gmail.com
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
// revision: 23/04/2005
 
// This include file contains vector operation utilities
#include "VectorXYZ.h"
#include <vector>
#include <string>

using namespace std;

// This class holds a molecule composed of "a" atoms
class Molecule {

  // name of each atom
  vector <string>* siteName;
  // position of each atom - vector containing 3 coordinates
  vector <Vector>* sitePosition;	
  // mass of each atom
  vector <double>* siteMass;
  // diameter of each atom
  vector <double>* siteSigma;
  // mass of molecule
  double totalMass;
  // centre of mass of molecule - vector containing 3 coordinates
  Vector CM;	

		
 public:
	
  // Allocate memory for a molecule of size "a"
  Molecule(int a) {
    siteName = new vector <string> (a);
    sitePosition = new vector <Vector> (a);
    siteMass = new vector <double> (a);
    siteSigma = new vector <double> (a);
    totalMass=0;
		
  }
  // Clear memory
  ~Molecule() {
    delete siteName;
    delete sitePosition;		
    delete siteMass;
    delete siteSigma;
  }
			
  // Read coordinates of atoms	
  void readPosition(istream& input) {

    string x,y,z;

    CM = 0.0;
    // loop over all atoms		
    for (int i=0; i< size(); i++) {		
      // read the 3 coordinates
      input >> x;
      input >> y;
      input >> z;	  		

      cout << x << " " << y << " " << z << endl;			
      // assign coordinates to vector "*sitePosition"
      (*sitePosition)[i] = Vector( atof(x.c_str()), atof(y.c_str()), atof(z.c_str()) );
      cout << (*sitePosition)[i].X() << "  " << (*sitePosition)[i].Y() << "  "<< (*sitePosition)[i].Z() << endl;
			
      // increment molecule centre of mass
      CM += (*sitePosition)[i] * (*siteMass)[i];
    }
    // calculate molecule centre of mass
    CM /= totalMass;
  }

  // Move molecule by -z in the z direction
  // This is used to move the origin of the box to "z" and move all atoms accordingly, 
  //  using periodic boundary conditions.
  void recenter(double z, double boxSize) {

    // loop over all atoms
    for (int i=0; i< size(); i++) {

      // move each atom by -z in z direction
      (*sitePosition)[i] -= Vector(0.0, 0.0, z );

      // apply periodic boundary conditions
      if ( (*sitePosition)[i].Z() < 0) { 
	(*sitePosition)[i] += Vector (0,0, boxSize);
      }
      if ( (*sitePosition)[i].Z() > boxSize) { 
	(*sitePosition)[i] -= Vector (0,0, boxSize);
      }
    }
    
  }
	
		
  // Print properties of molecule
  void print() {
    for (int i=0; i< size(); i++) {
      //			cout << (*siteName)[i] << "\t" << (*siteMass)[i]  << "\t" << (*siteCharge)[i];
      cout << (*siteName)[i] << "\t" << (*siteSigma)[i];			
      (*sitePosition)[i].print();	
    }
  }
	
  // Return name
  const string name(int i) {
	
    return (*siteName)[i];
  }
	
  // Assign name
  void giveName(int i, string name) {

    (*siteName)[i]=name;

  }

  // Return position vector
  Vector position (int i) {
	
    return (*sitePosition)[i];
  }

  // Assign position vector
  void givePosition(int i, Vector pos) {

    (*sitePosition)[i]=pos;

  }

  // Assign position vector
  void givePosition(int i, double x, double y, double z) {

    (*sitePosition)[i]=Vector(x,y,z);

  }

  // Return mass
  double mass (int i) {
	
    return (*siteMass)[i];
  }

  // Assign mass
  void giveMass(int i, double mass) {

    (*siteMass)[i]=mass;

  }

  // Assign totalmass
  void giveTotMass(double mass) {

    totalMass=mass;

  }

  // Return diameter
  double sigma (int i) {
	
    return (*siteSigma)[i];
  }

  // Assign diameter
  void giveSigma(int i, double sigma) {

    (*siteSigma)[i]=sigma;

  }

  // Return size (number of atoms) of molecule
  int size() { return siteName->size(); }
	

  Molecule& operator=(const Molecule& a) { // copy assignment
	
    //atenï¿½o: coloquei this nesta primeira secï¿½o; falta testar; sem funciona OK.	
	
    (*this).siteName = new vector <string> (a.siteName->size() );
    (*this).sitePosition = new vector <Vector> (a.siteName->size() );
    (*this).siteMass = new vector <double> (a.siteName->size() );
    (*this).siteSigma = new vector <double> (a.siteSigma->size() );
		
    for (int i=0; i<a.siteName->size(); i++) {
      (* (*this).siteName)[i] = (*a.siteName)[i];
      (* (*this).sitePosition)[i] = (*a.sitePosition)[i];			
      (* (*this).siteMass)[i] = (*a.siteMass)[i];
      (* (*this).siteSigma)[i] = (*a.siteSigma)[i];
    }
    return *this;
  }
	
  // Return total mass of molecule
  double mass() {
    return totalMass;
  }	

  // Return centre of mass of molecule (vector)
  Vector cm() {
    return CM;
  }
		
};


// This class holds a vector composed of "m" Molecules
class VMolecule {

  vector <Molecule*> m;
  // mass of phase
  double totMass;
	
 public:
	
  VMolecule() {	}

  // Create a vector of "vsize" Molecules, each of size "msize"
  VMolecule(int vSize, int mSize) {
	
    // loop over all molecules
    for (int i=0; i<vSize; i++) {
      // allocate memory for one molecule of size "msize"
      m.insert(m.end(), new Molecule(mSize) );
    }	
  }
	
  // Return object instead of pointer
  Molecule& operator[] (const int i) {
    return *(m[i]);
  }	

  // Read positions of all molecules (3D coordinate vector)
  void readPosition(istream& input) {	
    for (int i=0; i< m.size(); i++) {
      cout << i << " ";	
      m[i]->readPosition(input);
    }	
  }	
	
  // Print properties and positions of all molecules
  void print() {

    for (int i=0; i< m.size(); i++) {	
      cout << "Molecule: " << i << endl;
      m[i]->print();
    }	
  }	
	
  // Calculate total atoms in phase (number of atoms in molecule * number of molecules)
  int totalAtoms() {
	
    int total=0;
	
    // loop over all molecules
    for (int i=0; i<m.size(); i++) {
      // increment counter by size of molecule
      total += (*m[i]).size();
    }
		
    return total;
  }

  // Return size of vector (number of molecules)	
  int size() { return m.size(); }


  VMolecule& operator=( const VMolecule& vm)	{	// copy constructor
	
    for (int i=0; i<vm.m.size(); i++) {
			
      (*this).m[i]= new Molecule (vm.m.size() );
			
      (* (*this).m[i]) = *(vm.m[i]);
    }
    return *this;
  }

  // Sort molecules according to the z position of atom "atom"
  //  start at "start" and move in the direction given by "direction" (positive or negative)
  void sortZ( double start, int direction, int atom, vector <int>& sorted ) {

    if (atom<0) atom=-atom;
    if (atom>(m[0]->size())) atom=m[0]->size();

    // double loop over all pairs of different molecules
    for (int i=0; i<m.size() - 1 ; i++) {		
      for (int j=i+1; j<m.size(); j++) {		

        // compare z position of atom
	double zi = direction*(m[ sorted[i] ]->position(atom).Z() - start);
	if (zi<0.0) zi += 2*start;
	double zj = direction*(m[ sorted[j] ]->position(atom).Z() - start);
	if (zj<0.0) zj += 2*start;
	//cout << start + direction*zj << "  " << start + direction*zi << endl;
	if ( zj < zi ) {
          // swap order of molecules
	  int tmp = sorted[i];					
	  sorted[i] = sorted[j];
	  sorted[j] = tmp;					
	}
      }
    }

  }
	
  // Sort molecules according to the z position of their closest atom to start
  //  start at "start" and move in the direction given by "direction" (positive or negative)
  void sortZ( double start, int direction, vector <int>& sorted ) {

    // double loop over all pairs of different molecules
    for (int i=0; i<m.size() - 1 ; i++) {
      for (int j=i+1; j<m.size(); j++) {		

	double zi=100000.;
	double zj=100000.;

	// find atoms closest to start along direction
	for (int ii=0; ii<(m[sorted[i]]->size()); ii++) {
	  if ((m[sorted[i]]->sigma(ii))>0.0) {
	    double new_zi = direction*(m[ sorted[i] ]->position(ii).Z() - start);
	    if (new_zi<0.0) new_zi += 2*start;
	    if (new_zi<zi) zi=new_zi;
	  }
	}
	for (int jj=0; jj<(m[sorted[j]]->size()); jj++) {
	  if ((m[sorted[j]]->sigma(jj))>0.0) {
	    double new_zj = direction*(m[ sorted[j] ]->position(jj).Z() - start);
	    if (new_zj<0.0) new_zj += 2*start;
	    if (new_zj<zj) zj=new_zj;
	  }
	}

	//cout << start + direction*zj << "  " << start + direction*zi << endl;
	if ( zj < zi ) {
          // swap order of molecules
	  int tmp = sorted[i];					
	  sorted[i] = sorted[j];
	  sorted[j] = tmp;					
	}
      }
    }

  }
	
  // Sort atoms according to their z position 
  //  start at "start" and move in the direction given by "direction" (positive or negative)
  void sortZ_a( double start, int direction, vector <int>& sorted ) {

    // double loop over all pairs of different atoms

    int organicMolecule = m[0]->size();
    for (int i=0; i<m.size()*organicMolecule-1; i++) {
      for (int j=i+1; j<m.size()*organicMolecule; j++)  {

	int indexI = sorted[i]/organicMolecule;
	int indexII = sorted[i]%organicMolecule;
	int indexJ = sorted[j]/organicMolecule;
	int indexJJ = sorted[j]%organicMolecule;

	// compare z position of atom
	double zi = direction*(m[indexI]->position(indexII).Z() - start);
	if (zi<0.0) zi += 2*start;
	double zj = direction*(m[indexJ]->position(indexJJ).Z() - start);
	if (zj<0.0) zj += 2*start;
	//cout << start + direction*zj << "  " << start + direction*zi << endl;
	if ( zj < zi ) {
	  // swap order of molecules
	  int tmp = sorted[i];					
	  sorted[i] = sorted[j];
	  sorted[j] = tmp;					
	}

      }
    }

  }

  // Calculate global centre of mass of phase
  Vector cm() {
    Vector tmp;
    double mass=0;
    // loop over all molecules
    for (int i=0; i< m.size(); i++) {
      // increment "tmp" by molecule COM * molecule mass
      tmp += m[i]->cm() * m[i]->mass();
      // increment total mass
      mass += m[i]->mass();
    }
    totMass = mass;
    // calculate COM of phase
    return tmp/mass;
  }

  // return total mass of VMolecule
  double totalMass() {
    return totMass;
  }

  // Recentre phase, moving all molecules by -z
  void recenter(double z, double boxSize) {
    for (int i=0; i< m.size(); i++) {	
      m[i]->recenter(z, boxSize);
    }
  }
		
		
};


// This class holds cummulative values of a given property. It is used for averaging.
class Property {
  // cummulative value of property
  double value;
  // cummulative squared value of property
  double squared;
  // counter for number of values added
  double counter;

 public:

  // create empty Property	
  Property() { value = squared = counter = 0; }
	
  // add a value to the Property
  void add(double a) {
    // increment value sum
    value += a;
    // increment squared value sum
    squared += a*a;
    // increment counter
    counter++;
  }
	
  // Calculate and return average of property (average of all values added)
  double average() { return value/counter; }
	
  // calculate and return standard deviation of property {SUM(x^2)/N - [SUM(X)]^2/N^2}
  double std() { return squared/counter - value*value/(counter*counter); }	
};


// class Box {
// 	Vector size;
// 	vector <VMolecule*> vm;
// 
// 	public:
// 	
// 	Box () {
// 		size = Vector(0,0,0);
// 	}
// 
// 	void addVmolecules( vector <VMolecule*> a) {
// 	
// 			m.insert(m.end(), new vMolecule(mSize) );
// 
// 		
// 
// 	void add(double a) {
// 		value += a;
// 		squared += a*a;
// 		counter++;
// 	}
// 	
// 	
// 	double average() { return value/counter; }
// 	
// 	double std() { return squared/counter - value*value/(counter*counter); }	
// };









