#$ -N ITIM
#$ -cwd                  
#$ -pe sharedmem 1
#$ -l h_rt=48:00:00 
#$ -l h_vmem=2G

# Initialise the environment modules
. /etc/profile.d/modules.sh 
module load eng/gromacs
export LD_LIBRARY_PATH=/usr/lib64/

gmx_mpi dump -f traj_comp_05000.xtc | ./xtc.pl 500 25 500 7 100 3 100 3 | ./itim5 - param.inp