/***************************************************************************
                          xtc.h  - reading xtc files
                             -------------------
    begin                : Sat Apr 16 2005
    copyright            : (C) 2005 by Daniel dos Santos
    email                : dos.santos.daniel@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
#include <iostream>

 
using namespace std;

// This class holds the coordinates of a cubic box
 class XtcBox {
	double x,y,z;

	public:
	
	// create null box
	XtcBox() { x=y=z=0; }
	
        // read the coordinates
	void read (istream& input) {
		string word;
		
		input >> word;
		x = atof(word.c_str());
	
		input >> word;
		y = atof(word.c_str());
	
		input >> word;
		z = atof(word.c_str());
	}
        // print all coordinates
	void print() {
		cout << x << "\t" << y << "\t" << z << "\t" << endl;
	}
        // return each coordinate separately
	double X() { return x; }
	double Y() { return y; }
	double Z() { return z; }
};


// This class holds cummulative values of a given property. It is used for averaging.
class Property {
  // cummulative value of property
  double value;
  // cummulative squared value of property
  double squared;
  // counter for number of values added
  double counter;

 public:

  // create empty Property	
  Property() { value = squared = counter = 0; }
	
  // add a value to the Property
  void add(double a) {
    // increment value sum
    value += a;
    // increment squared value sum
    squared += a*a;
    // increment counter
    counter++;
  }
	
  // Calculate and return average of property (average of all values added)
  double average() { return value/counter; }
	
  // calculate and return standard deviation of property {SUM(x^2)/N - [SUM(X)]^2/N^2}
  double std() { return squared/counter - value*value/(counter*counter); }	
};



