/***************************************************************************
    xtc_interface.C - Analysis of Gromacs XTC files for Interfaces
    ------------------- begin : Fri Apr 16 2001 copyright : (C) 2005
    by Daniel dos Santos email : dos.santos.daniel@gmail.com modified
    : Wed Nov 28 2007 mod. by : Miguel Jorge
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

//V1.0 28/11/2007

#include <fstream>
#include <string>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
#include <sstream>

#include "VectorXYZ.h"
#include "xtc.h"

// Global parameters
#define PI M_PI
#define R 8.314472
#define kB 1.3806504e-23
#define Nav 6.02214179e23

using namespace std;

// Global variables;
int nSlabs; // number of slabs for profile calculations
int Ng1, Ng2; // Number of test lines for ITIM
double Rp1, Rp2; // Probe sphere radii for ITIM (nm)
int nSpec; // total number of species in simulation
int *maxMols = NULL; // maximum number of molecules of each species [nSpec]
int *nMols = NULL; // number of molecules of each species [nSpec]
int *nMols1 = NULL; // number of molecules of each species in phase 1 [nSpec]
int *nMols2 = NULL; // number of molecules of each species in phase 2 [nSpec]
int *nSites = NULL; // number of sites on each molecule [nSpec]
//int *SpecPhase = NULL; // phase to which species belongs (takes values 1 or 2) [nSpec]
double **Mass = NULL; // Mass of each site [nSpec][nSites] (g/mol)
double **Charge = NULL; // Charge of each site [nSpec][nSites] (a.u.)
double **Sigma = NULL; // Sigma of each site [nSpec][nSites] (nm)
double **Epsilon = NULL; // Epsilon of each site [nSpec][nSites] (kJ/mol)
int **Profile = NULL; // Flag to calculate density profiles [nSpec][nSites]
Vector ***Coords = NULL; // molecular coordinates for each species [nSpec][nMols][nSites] (nm)
double ***DensGl = NULL; // global density profile [nSpec][nSites][nSlabs]
double ***IntDensGl = NULL; // global interfacial density profile [nSpec][nSites][nSlabs]
double ***DensL1 = NULL; // intrinsic density profile relative to left of phase 1 [nSpec][nSites][nSlabs]
double ***DensR1 = NULL; // intrinsic density profile relative to right of phase 1 [nSpec][nSites][nSlabs]
double ***DensL2 = NULL; // intrinsic density profile relative to left of phase 2 [nSpec][nSites][nSlabs]
double ***DensR2 = NULL; // intrinsic density profile relative to right of phase 2 [nSpec][nSites][nSlabs]
double ***IntDensL1 = NULL; // intrinsic interfacial density profile relative to left of phase 1 [nSpec][nSites][nSlabs]
double ***IntDensR1 = NULL; // intrinsic interfacial density profile relative to right of phase 1 [nSpec][nSites][nSlabs]
double ***IntDensL2 = NULL; // intrinsic interfacial density profile relative to left of phase 2 [nSpec][nSites][nSlabs]
double ***IntDensR2 = NULL; // intrinsic interfacial density profile relative to right of phase 2 [nSpec][nSites][nSlabs]
bool **IntFlag1, **IntFlag2 = NULL; // flags to determine if a molecule is interfacial
int nAtoms1, nAtoms2; // total number of atoms on each phase
Vector *phase1, *phase2 = NULL; // Arrays to hold phases [nAtoms] (nm)
int *sorted1, *sorted2 = NULL; // arrays to sort phase atoms [nAtoms]
double *dist1, *dist2 = NULL; // distances for sorting phases [nAtoms] (nm)
double *RprobeSq1, *RprobeSq2 = NULL; // Collision radii of each atom with probe spheres [nAtoms] (nm2)
int *species1, *species2 = NULL; // arrays to map phases to species
int *molecule1, *molecule2 = NULL; // arrays to map phases to molecules
double *Lint1_pos, *Rint1_pos, *Lint2_pos, *Rint2_pos = NULL; // probe sphere position array, added by gyorgy
int *Lint1_grsite, *Rint1_grsite, *Lint2_grsite, *Rint2_grsite = NULL; // array of sites belonging to each grid point, added by gyorgy
bool one_phase; // added by gyorgy
double ***dist_L1, ***dist_R1 = NULL; // these arrays will contain the distance of each interfacial site form the left/right side of phase1. gyorgy2

inline bool sign(double n) { 
  return n>=0.0;
}

// sort arrays ra[] and sorted[], both of size n, according to value of ra[]
void hpsort(double ra[], int n, int sorted[]) {

  int p,f,rt,rmax;
  double max,t;

  // build heap
  for (int m=1; m<n; m++) {
    f=m+1;
    t=ra[f];
    rt=sorted[f];
    while (f>1 && ra[p=f/2]<t) {
      ra[f]=ra[p];
      sorted[f]=sorted[p];
      f=p;
    }
    ra[f]=t;
    sorted[f]=rt;
  }

  // sort heap
  for (int m=n; m>1; m--) {
    max=ra[1];
    rmax=sorted[1];
    p=1, f=2;
    while (f<=m) {
      if (f<m && ra[f]<ra[f+1]) ++f;
      ra[p]=ra[f];
      sorted[p]=sorted[f];
      p=f, f=2*p;
    }
    f=p;
    if (f<m) {
      t=ra[m];
      rt=sorted[m];
      while (f>1 && ra[p=f/2]<t) {
	ra[f]=ra[p];
	sorted[f]=sorted[p];
	f=p;
      }
      ra[f]=t;
      sorted[f]=rt;
    }
    ra[m]=max;
    sorted[m]=rmax;
  }
}


int main ( int argc, char* argv[] ) {
 
  string word;

  // Allow only 2 or 3 args (plus executable)
  if (argc < 3 || argc > 4) {
    cout << "Usage: " << argv[0] << " data_file parameter_file n_steps \n";
    exit(1);
  }

  // 1st arg is input data file
  istream *input;
  if ( string (argv[1]) == "-" ) {	
    // if no file is specified, read from console
    input = &cin;
  } else {
    input = new ifstream(argv[1], ios::in);		
  }

  // 2nd arg is input parameter file
  istream *param;
  param = new ifstream(argv[2], ios::in);

  long nSteps;  
  // 3rd arg is number of steps (optional)
  if ( argc == 4 ) {
    nSteps = atoi(argv[3]);	
  } else {
    nSteps = 99999999; // to change when the total number is known
  }		

  // read input parameter file
  cout << "READING INPUT FILE" << endl;
  while (*param >> word) {

    // general simulation data
    nSlabs = atoi(word.c_str()); // number of slabs for profiles
    *param >> word;
    nSpec = atoi(word.c_str()); // total number of different species
    maxMols = new int[nSpec];
    nMols = new int[nSpec];
    nMols1 = new int[nSpec];
    nMols2 = new int[nSpec];
    nSites = new int[nSpec];
    //SpecPhase = new int[nSpec];
    Mass = new double*[nSpec];
    Charge = new double*[nSpec];
    Sigma = new double*[nSpec];
    Epsilon = new double*[nSpec];
    Profile = new int*[nSpec];

    // phase 1 parameters
    *param >> word;
    Ng1 = atoi(word.c_str()); // number of test lines in x direction
    *param >> word;
    Rp1 = atof(word.c_str()); // probe sphere radius
    // phase 2 // these lines have no useful information if the system has only one phase. they are kept to be consistent with the usual file format. gyorgy
    *param >> word;
    Ng2 = atoi(word.c_str()); 
    *param >> word;
    Rp2 = atof(word.c_str()); 

    for (int i=0; i<nSpec; i++) { // loop over all species
      *param >> word;
      maxMols[i] = atoi(word.c_str()); // maximum number of molecules
      *param >> word;
      nSites[i] = atoi(word.c_str()); // number of sites in each molecule
      //*param >> word; // ERASE, gy
      //SpecPhase[i] = atoi(word.c_str()); // phase to which species belongs // ERASE, gy
      //if (SpecPhase[i]!=1 && SpecPhase[i]!=2) { // ERASE, gy
      //  cout << "ERROR: Invalid phase for species " << nSpec << endl << endl; // ERASE, gy
      //  exit(1); // ERASE, gy
      //} // ERASE, gy
      Mass[i] = new double[nSites[i]];
      Charge[i] = new double[nSites[i]];
      Sigma[i] = new double[nSites[i]];
      Epsilon[i] = new double[nSites[i]];
      Profile[i] = new int[nSites[i]];
      for (int j=0; j<nSites[i]; j++) {
	*param >> word;
	Mass[i][j] = atof(word.c_str());
	*param >> word;
	Charge[i][j] = atof(word.c_str());
	*param >> word;
	Sigma[i][j] = atof(word.c_str());
	*param >> word;
	Epsilon[i][j] = atof(word.c_str());
	*param >> word;
	Profile[i][j] = atoi(word.c_str());
      }
    } 

  }

  // allocate coordinate vectors
  Coords = new Vector**[nSpec];
  dist_L1 = new double**[nSpec]; //gyorgy2
  dist_R1 = new double**[nSpec]; //gyorgy2
  for (int i=0; i<nSpec; i++) {
    Coords[i] = new Vector*[maxMols[i]];
    dist_L1[i] = new double*[maxMols[i]]; // gyorgy2
    dist_R1[i] = new double*[maxMols[i]]; // gyorgy2
    for (int j=0; j<maxMols[i]; j++) {
      Coords[i][j] = new Vector[nSites[i]];
      dist_L1[i][j] = new double[nSites[i]]; //gyorgy2
      dist_R1[i][j] = new double[nSites[i]]; //gyorgy2
    }
  }

  // allocate density vectors and flags
  DensGl = new double**[nSpec];
  IntDensGl = new double**[nSpec];
  DensL1 = new double**[nSpec];
  DensR1 = new double**[nSpec];
  DensL2 = new double**[nSpec]; // useless in one-phase case, gyorgy 08/04
  DensR2 = new double**[nSpec]; // useless in one-phase case, gyorgy 08/04
  IntDensL1 = new double**[nSpec];
  IntDensR1 = new double**[nSpec];
  IntDensL2 = new double**[nSpec]; // useless in one-phase case, gyorgy 08/04
  IntDensR2 = new double**[nSpec]; // useless in one-phase case, gyorgy 08/04
  IntFlag1 = new bool*[nSpec];
  IntFlag2 = new bool*[nSpec]; // useless in one-phase case, gyorgy 08/04
  for (int k=0; k<nSpec; k++) {
    DensGl[k] = new double*[nSites[k]];
    IntDensGl[k] = new double*[nSites[k]];
    DensL1[k] = new double*[nSites[k]];
    DensR1[k] = new double*[nSites[k]];
    DensL2[k] = new double*[nSites[k]]; // useless in one-phase case, gyorgy 08/04
    DensR2[k] = new double*[nSites[k]]; // useless in one-phase case, gyorgy 08/04
    IntDensL1[k] = new double*[nSites[k]];
    IntDensR1[k] = new double*[nSites[k]];
    IntDensL2[k] = new double*[nSites[k]]; // useless in one-phase case, gyorgy 08/04
    IntDensR2[k] = new double*[nSites[k]]; // useless in one-phase case, gyorgy 08/04
    IntFlag1[k] = new bool[maxMols[k]];
    IntFlag2[k] = new bool[maxMols[k]]; // useless in one-phase case, gyorgy 08/04
    for (int j=0; j<nSites[k]; j++) {
      DensGl[k][j] = new double[nSlabs];
      IntDensGl[k][j] = new double[nSlabs]; 
      DensL1[k][j] = new double[nSlabs];
      DensR1[k][j] = new double[nSlabs];
      DensL2[k][j] = new double[nSlabs]; // useless in one-phase case, gyorgy 08/04
      DensR2[k][j] = new double[nSlabs]; // useless in one-phase case, gyorgy 08/04
      IntDensL1[k][j] = new double[nSlabs];
      IntDensR1[k][j] = new double[nSlabs];
      IntDensL2[k][j] = new double[nSlabs]; // useless in one-phase case, gyorgy 08/04
      IntDensR2[k][j] = new double[nSlabs]; // useless in one-phase case, gyorgy 08/04
      for (int i=0; i<nSlabs; i++) {
	DensGl[k][j][i]=0.0;
	IntDensGl[k][j][i]=0.0;
	DensL1[k][j][i]=0.0;
	DensR1[k][j][i]=0.0;
	DensL2[k][j][i]=0.0; // useless in one-phase case, gyorgy 08/04
	DensR2[k][j][i]=0.0; // useless in one-phase case, gyorgy 08/04
	IntDensL1[k][j][i]=0.0;
	IntDensR1[k][j][i]=0.0;
	IntDensL2[k][j][i]=0.0; // useless in one-phase case, gyorgy 08/04
	IntDensR2[k][j][i]=0.0; // useless in one-phase case, gyorgy 08/04
      }
    }
  }

  int maxAtoms=0.0;
  // build phase arrays
  for (int k=0; k<nSpec; k++) {
    maxAtoms += maxMols[k]*nSites[k];
  }
  phase1 = new Vector[maxAtoms];
  phase2 = new Vector[maxAtoms]; // useless in one-phase case, gyorgy 08/04
  //sorted1 = new int[maxAtoms]; // we don't sort them anymore, gyorgy 08/04
  //sorted2 = new int[maxAtoms]; // we don't sort them anymore, gyorgy 08/04
  dist1 = new double[maxAtoms];
  dist2 = new double[maxAtoms]; // useless in one-phase case, gyorgy 08/04
  RprobeSq1 = new double[maxAtoms];
  RprobeSq2 = new double[maxAtoms]; // useless in one-phase case, gyorgy 08/04
  species1 = new int[maxAtoms];
  species2 = new int[maxAtoms]; // useless in one-phase case, gyorgy 08/04
  molecule1 = new int[maxAtoms]; 
  molecule2 = new int[maxAtoms]; // useless in one-phase case, gyorgy 08/04

  // arrays to hold interfacial sites and probe sphere positions
  // to each grid point. added by gyorgy
  Lint1_pos = new double[Ng1*Ng1];
  Rint1_pos = new double[Ng1*Ng1];
  Lint2_pos = new double[Ng2*Ng2]; // useless in one-phase case, gyorgy 08/04
  Rint2_pos = new double[Ng2*Ng2]; // useless in one-phase case, gyorgy 08/04
  Lint1_grsite = new int[Ng1*Ng1];
  Rint1_grsite = new int[Ng1*Ng1];
  Lint2_grsite = new int[Ng2*Ng2]; // useless in one-phase case, gyorgy 08/04
  Rint2_grsite = new int[Ng2*Ng2]; // useless in one-phase case, gyorgy 08/04

  double lSlab;
  double slabVolume;  
  int nBlocks=0;
  int blc = 0;

  // these are properties that are going to be averaged
  Property lSlabPpt; // average slab length  
  Property NrIntMol1_Ppt; // average number of interfacial sites for phase 1
  Property NrIntMol2_Ppt;

  // for ITIM
  // arrays to hold test lines
  vector <double> lines_X1(Ng1*Ng1);
  vector <double> lines_Y1(Ng1*Ng1);
  vector <double> lines_X2(Ng2*Ng2); // useless in one-phase case, gyorgy 08/04
  vector <double> lines_Y2(Ng2*Ng2); // useless in one-phase case, gyorgy 08/04
  // vectors to determine if probe has been stopped before
  //vector <bool> stopped_1(Ng1*Ng1); // we don't use this anymore, gyorgy 08/04
  //vector <bool> stopped_2(Ng2*Ng2); // we don't use this anymore, gyorgy 08/04
  // counters for interfacial sites
  int Lint1_cnt = 0;
  int Rint1_cnt = 0;
  int Lint2_cnt = 0; // useless in one-phase case, gyorgy 08/04
  int Rint2_cnt = 0; // useless in one-phase case, gyorgy 08/04
  // vectors to hold interfacial sites
  int intAtoms = maxAtoms;//*.2; //maximum number of interfacial sites (~20% of maxAtoms for each interface)
  vector <int> Lint1_mol(intAtoms);
  vector <int> Rint1_mol(intAtoms);
  vector <int> Lint2_mol(intAtoms); // useless in one-phase case, gyorgy 08/04
  vector <int> Rint2_mol(intAtoms); // useless in one-phase case, gyorgy 08/04
  vector <bool> Lint1_flag(intAtoms);
  vector <bool> Rint1_flag(intAtoms);
  vector <bool> Lint2_flag(intAtoms); // useless in one-phase case, gyorgy 08/04
  vector <bool> Rint2_flag(intAtoms); // useless in one-phase case, gyorgy 08/04

  vector <ofstream *> SurfSitesOut(nSpec);
  for (int k=0; k<nSpec; k++) {
     
     string fileName;
     ostringstream ostr;
     ostr << k+1;  
     fileName = "SurfSites-sp" + ostr.str() + ".dat";
     SurfSitesOut[k] = new ofstream (fileName.c_str(), ios::out);
     SurfSitesOut[k]->setf(ios::fixed);
     SurfSitesOut[k]->precision(8);
  }

  //********************************* main cycle ************************************

  // Read trajectory
  cout << "READING!!" << endl;
  while ( *input >> word && nBlocks < nSteps) { 
	
    // Read block (one block per step)
    // read total number of atoms (not used)
    int nAtoms = atoi(word.c_str()); // DO WE NEED THIS? gyorgy

    //*input >> word;
    // read time (not used)
    //double time = atof(word.c_str());
	
    // read box dimensions
    XtcBox box;
    box.read(*input);
		
    // box dimensions and slab volumes
    double boxX = box.X();
    double boxY = box.Y();
    double boxZ = box.Z();
    double halfZ = box.Z()*0.5;
    double halfX = box.X()*0.5;
    double halfY = box.Y()*0.5;
    // density slab sizes and volumes
    lSlab = boxZ/nSlabs; // nm
    slabVolume = boxX * boxY * lSlab;
    // increment property to calculate average slab length
    lSlabPpt.add(lSlab);

    // read coordinates
    for (int k=0; k<nSpec; k++) {

      // read molecules that are in phase 1
      *input >> word;
      nMols1[k]=atoi(word.c_str());
      for (int i=0; i<nMols1[k]; i++) {
	for (int j=0; j<nSites[k]; j++) {
	  *input >> word;
	  double x=atof(word.c_str());
	  *input >> word;
	  double y=atof(word.c_str());
	  *input >> word;
	  double z=atof(word.c_str());
	  Coords[k][i][j]=Vector(x,y,z);
	}
      }

      // read molecules from phase 2 // if we read 0 molecules for each species, the system has only one phase. gyorgy
      *input >> word;
      nMols2[k]=atoi(word.c_str());
      for (int i=nMols1[k]; i<nMols1[k]+nMols2[k]; i++) {
	for (int j=0; j<nSites[k]; j++) {
	  *input >> word;
	  double x=atof(word.c_str());
	  *input >> word;
	  double y=atof(word.c_str());
	  *input >> word;
	  double z=atof(word.c_str());
	  Coords[k][i][j]=Vector(x,y,z);
	}
      }

      // check if all molecules were read
      if (nMols1[k]+nMols2[k]<maxMols[k]) {
	cout << "WARNING! Not all molecules of species " << k << " were read: " << nMols1[k] << " + " << nMols2[k] << " < " << maxMols[k] << endl;
      }
      if (nMols1[k]+nMols2[k]>maxMols[k]) {
	cout << "ERROR! Too many molecules of species " << k << " were read: " << nMols1[k] << " + " << nMols2[k] << " > " << maxMols[k] << endl;
	exit(1);
      }
      nMols[k] = nMols1[k]+nMols2[k]; //total number of molecules of each species

    }

    int nMols_ph2; // to check how many molecules we have in phase2, gyorgy
    nMols_ph2 = 0;
    for (int k=0; k<nSpec; k++) {
      nMols_ph2 += nMols2[k];
    }
    one_phase = false;
    if (nMols_ph2 == 0) {
      one_phase = true;
    }
    cout << one_phase << endl;

    // build phase arrays and compute COM of phase 1 (to be placed in the centre of the box)
    // we build RprobeSq1, species1 and molecule1 arrays here
    int count1=0;
    int count2=0; // useless in one-phase case, gyorgy 08/04
    double totMass1=0.0;
    double zMass1=0.0;
    for (int k=0; k<nSpec; k++) { //loop over each species
      for (int i=0; i<nMols1[k]; i++) { //loop over all molecules of k that belong to phase 1
	for (int j=0; j<nSites[k]; j++) { //loop over all sites of k
	  if (Sigma[k][j]>0.0) { //disregard sites without a van der Waals radius
	    phase1[count1] = Coords[k][i][j]; //assign coordinates to phase array
	    RprobeSq1[count1] = (Rp1+0.5*Sigma[k][j])*(Rp1+0.5*Sigma[k][j]); //assign collision radius
	    species1[count1] = k; //which species?
	    molecule1[count1] = i; //which molecule?
	    totMass1 += Mass[k][j]; //add to total mass
	    zMass1 += Mass[k][j]*phase1[count1].Z(); //for COM calculation
	    count1++; //increment counter for sites of phase 1
	  }
	}
      }
      for (int i=nMols1[k]; i<nMols1[k]+nMols2[k]; i++) { //repeat process for phase 2 // this will be executed 0 times in the one-phase case, gyorgy 08/04
	for (int j=0; j<nSites[k]; j++) {
	  if (Sigma[k][j]>0.0) {
	    phase2[count2] = Coords[k][i][j];
	    RprobeSq2[count2] = (Rp2+0.5*Sigma[k][j])*(Rp2+0.5*Sigma[k][j]);
	    species2[count2] = k;
	    molecule2[count2] = i;
	    count2++;
	  }
	}
      }
    }
    double zCOM1=zMass1/totMass1; // calculate COM
    //double zCOM2=zMass2/totMass2;
    int nAtoms1 = count1;
    int nAtoms2 = count2; // useless in one-phase case, gyorgy 08/04
    cout << nAtoms1 << "  " << nAtoms2 << endl; // modify this, gyorgy 08/04

    //for (int i=0; i<nAtoms2; i++) {
    //cout << phase2[i].X() << " " << phase2[i].Y() << " " << phase2[i].Z() << endl;
    //}

    // Recenter system, moving the centre of the box to the centre of mass of phase 1.
    // This way, phase 1 is in the middle of the box and phase 2 on the sides
    for (int i=0; i<nAtoms1; i++) {
      phase1[i] -= Vector(0,0,zCOM1-halfZ);
      // apply periodic boundary conditions
      if ( phase1[i].Z() < 0) { 
	phase1[i] += Vector (0,0,boxZ);
      }
      if ( phase1[i].Z() > boxZ) { 
	phase1[i] -= Vector (0,0,boxZ);
      }
      // sorted1[i] = i; // array to sort molecules // we don't need this since we don't sort them anymore // gyorgy
      dist1[i] = phase1[i].Z(); // distance to left interface in z direction
    }
    for (int i=0; i<nAtoms2; i++) { // this will be executed 0 times in one-phase case, gyorgy
      phase2[i] -= Vector(0,0,zCOM1-halfZ);
      if ( phase2[i].Z() < 0) { 
	phase2[i] += Vector (0,0,boxZ);
      }
      if ( phase2[i].Z() > boxZ) { 
	phase2[i] -= Vector (0,0,boxZ);
      }
      //sorted2[i] = i;  // we don't need this since we don't sort them anymore // gyorgy
      dist2[i] = halfZ-phase2[i].Z(); // z distance to left interface from box centre
      if (dist2[i]<0.0) dist2[i]+=boxZ; // need to apply PBC in this phase
    }
    for (int k=0; k<nSpec; k++) {
      for (int i=0; i<nMols[k]; i++) {
	for (int j=0; j<nSites[k]; j++) {
	  Coords[k][i][j] -= Vector(0,0,zCOM1-halfZ);
	  if ( Coords[k][i][j].Z() < 0) { 
	    Coords[k][i][j] += Vector (0,0,boxZ);
	  }
	  if ( Coords[k][i][j].Z() > boxZ) { 
	    Coords[k][i][j] -= Vector (0,0,boxZ);
	  }
	}
      }
    } // 

    // ----------- DETERMINE INTERFACIAL MOLECULES ----------- //

    double LAvgIntPos1 = 0.0; // Average interface positions
    double RAvgIntPos1 = 0.0;
    double LAvgIntPos2 = 0.0;
    double RAvgIntPos2 = 0.0;

    // Phase 1
    // set up test lines and reset stopped vector
    double nX = boxX/Ng1;
    double nY = boxY/Ng1;
    int NgSq1 = Ng1*Ng1;
    int ii=0;
    for (int x=0; x<Ng1; x++) { // x
      for (int y=0; y<Ng1; y++) { // y
	lines_X1[ii] = (x+.5)*nX;
	lines_Y1[ii] = (y+.5)*nY;
        Lint1_pos[ii] = 100000.;
	Rint1_pos[ii] = -100000.;
	ii++;
      }
    }

    // Reset interfacial molecule flags
    for (int k=0; k<nSpec; k++) {
      for (int i=0; i<nMols[k]; i++) {
	IntFlag1[k][i] = false; // set flags
	IntFlag2[k][i] = false; // set flags
      }
    }

    // LEFT PHASE 1 INTERFACE
    
    // reset interfacial site flags
    for (int i=0; i<nAtoms1; i++) {
      Lint1_flag[i] = false;
    }

    // loop over all sites
    Lint1_cnt = 0; // reset counter for interfacial sites
    for (int i=0; i<nAtoms1; i++) {

      int ii=i;
      //cout << phase1[i].Z() << " " << RprobeSq1[ii] << " " << species1[ii] << " " << molecule1[ii] << endl;

      // loop over all test lines
      for (int n=0; n<NgSq1; n++) {

	  // calculate distance between atom and probe sphere (use PBC)
	  double rx = phase1[ii].X() - lines_X1[n];
	  if (rx>halfX) {
	    rx -= boxX;
	  } else if (-rx>halfX) {
	    rx += boxX;
	  }
	  double ry = phase1[ii].Y() - lines_Y1[n];
	  if (ry>halfY) {
	    ry -= boxY;
	  } else if (-ry>halfY) {
	    ry += boxY;
	  }

	  // if atom is within collision radius
          // this part is modified to identify surface sites as is done in Livia's code. modified by gyorgy
          if (rx*rx + ry*ry < RprobeSq1[ii]) {
            double dx2 = RprobeSq1[ii] - (rx*rx + ry*ry);
            double dx = sqrt(dx2);
            if (Lint1_pos[n] > phase1[ii].Z() - dx) {
              Lint1_pos[n] = phase1[ii].Z() - dx;
              Lint1_grsite[n] = ii;
            }
          }
      }
    }

      for (int n=0; n<NgSq1; n++) {
        int ii = Lint1_grsite[n];
        if (!Lint1_flag[ii]) {
              Lint1_flag[ii] = true; // set flag2 to interfacial
              IntFlag1[species1[ii]][molecule1[ii]] = true;
              Lint1_mol[Lint1_cnt] = ii; // store molecule as interfacial
              Lint1_cnt++; // increment counter for interfacial molecules
              LAvgIntPos1 += phase1[ii].Z(); // increment average position
        }
      }

    NrIntMol1_Ppt.add(Lint1_cnt);
    cout << "Phase1 Left = " << Lint1_cnt << endl;

    // RIGHT PHASE 1 INTERFACE
    
    // reset interfacial flags
    for (int i=0; i<nAtoms1; i++) {
      Rint1_flag[i] = false;
    }

    Rint1_cnt = 0; 
    for (int i=nAtoms1-1; i>=0; i--) {

      int ii=i;

      for (int n=0; n<NgSq1; n++) {

	  double rx = phase1[ii].X() - lines_X1[n];
	  if (rx>halfX) {
	    rx -= boxX;
	  } else if (-rx>halfX) {
	    rx += boxX;
	  }
	  double ry = phase1[ii].Y() - lines_Y1[n];
	  if (ry>halfY) {
	    ry -= boxY;
	  } else if (-ry>halfY) {
	    ry += boxY;
	  }

	  if (rx*rx + ry*ry < RprobeSq1[ii]) {
            double dx2 = RprobeSq1[ii] - (rx*rx + ry*ry);
            double dx = sqrt(dx2);
            if (Rint1_pos[n] < phase1[ii].Z() + dx) {
              Rint1_pos[n] = phase1[ii].Z() + dx;
              Rint1_grsite[n] = ii;
            }
          }
      }
    }

      for (int n=0; n<NgSq1; n++) {
        int ii = Rint1_grsite[n];
        if (!Rint1_flag[ii]){
              Rint1_flag[ii] = true;
              IntFlag1[species1[ii]][molecule1[ii]] = true;
              Rint1_mol[Rint1_cnt] = ii;
              Rint1_cnt++;
              RAvgIntPos1 += phase1[ii].Z();
            }
          }
	  
    NrIntMol1_Ppt.add(Rint1_cnt);
    cout << "Phase1 Right = " << Rint1_cnt << endl;

   if (!one_phase) { // i.e. we have two phases - gyorgy
    // Phase 2
    // set up test lines and reset stopped vector
    nX = boxX/Ng2;
    nY = boxY/Ng2;
    int NgSq2 = Ng2*Ng2;
    ii=0;
    for (int x=0; x<Ng2; x++) { // x
      for (int y=0; y<Ng2; y++) { // y
	lines_X2[ii] = (x+.5)*nX;
	lines_Y2[ii] = (y+.5)*nY;
        Lint2_pos[ii] = -100000.;
	Rint2_pos[ii] = 100000.;
	ii++;
      }
    }

    // LEFT PHASE 2 INTERFACE

  
    // reset interfacial flags
    for (int i=0; i<nAtoms2; i++) {
      Lint2_flag[i] = false;
    }

    // loop over all atoms
    Lint2_cnt = 0; // reset counter for interfacial atoms
    for (int i=0; i<nAtoms2; i++) {

      int ii=i;

      // loop over all test lines
      for (int n=0; n<NgSq2; n++) {

	  // calculate distance between atom and probe sphere (use PBC)
	  double rx = phase2[ii].X() - lines_X2[n];
	  if (rx>halfX) {
	    rx -= boxX;
	  } else if (-rx>halfX) {
	    rx += boxX;
	  }
	  double ry = phase2[ii].Y() - lines_Y2[n];
	  if (ry>halfY) {
	    ry -= boxY;
	  } else if (-ry>halfY) {
	    ry += boxY;
	  }

	  // if atom is within collision radius
	  if (rx*rx + ry*ry < RprobeSq2[ii]) {
            double dx2 = RprobeSq2[ii] - (rx*rx + ry*ry);
            double dx = sqrt(dx2);
            if (Lint2_pos[n] < dist2[ii] + dx) { // dist2[] instead of phase2[].Z(), modified by gyorgy
              Lint2_pos[n] = dist2[ii] + dx;
              Lint2_grsite[n] = ii;
            }
          }
      }
    }
      for (int n=0; n<NgSq2; n++) {
        int ii = Lint2_grsite[n];
        if (!Lint2_flag[ii]) {
              Lint2_flag[ii] = true; // set flag to interfacial
              IntFlag2[species2[ii]][molecule2[ii]] = true;
              Lint2_mol[Lint2_cnt] = ii; // store molecule as interfacial
              Lint2_cnt++; // increment counter for interfacial molecules
              LAvgIntPos2 += phase2[ii].Z(); // increment average position
        }
      }

    NrIntMol2_Ppt.add(Lint2_cnt);
    cout << "Phase2 Left = " << Lint2_cnt << endl;

    // RIGHT PHASE 2 INTERFACE
    
    // reset interfacial flags
    for (int i=0; i<nAtoms2; i++) {
      Rint2_flag[i] = false;
    }

    Rint2_cnt = 0; 
    for (int i=nAtoms2-1; i>=0; i--) {

      int ii=i;

      for (int n=0; n<NgSq2; n++) {

	  double rx = phase2[ii].X() - lines_X2[n];
	  if (rx>halfX) {
	    rx -= boxX;
	  } else if (-rx>halfX) {
	    rx += boxX;
	  }
	  double ry = phase2[ii].Y() - lines_Y2[n];
	  if (ry>halfY) {
	    ry -= boxY;
	  } else if (-ry>halfY) {
	    ry += boxY;
	  }

	  if (rx*rx + ry*ry < RprobeSq2[ii]) {
            double dx2 = RprobeSq2[ii] - (rx*rx + ry*ry);
            double dx = sqrt(dx2);
            if (Rint2_pos[n] > dist2[ii] - dx) {
              Rint2_pos[n] = dist2[ii] - dx;
              Rint2_grsite[n] = ii;
            }
          }
      }
    }

      for (int n=0; n<NgSq2; n++) {
        int ii = Rint2_grsite[n];
        if (!Rint2_flag[ii]) {
              Rint2_flag[ii] = true;
              IntFlag2[species2[ii]][molecule2[ii]] = true;
              Rint2_mol[Rint2_cnt] = ii;
              Rint2_cnt++;
              RAvgIntPos2 += phase2[ii].Z();
        }
      }

    NrIntMol2_Ppt.add(Rint2_cnt);
    cout << "Phase2 Right = " << Rint2_cnt << endl;

   } // the end of the analysis of phase 2

    // ----------- CALCULATE NUMBER DENSITIES ----------- //
    
    // Find average interface positions
    LAvgIntPos1 /= Lint1_cnt;
    RAvgIntPos1 /= Rint1_cnt;
    if (!one_phase) { // we have two phases. L/Rint2_cnt is supposed to be 0 here. gyorgy
      LAvgIntPos2 /= Lint2_cnt;
      RAvgIntPos2 /= Rint2_cnt;
    }
    double interpol;
    int slice;
    double x1;
    double y1;
    double z1;
    double x2;
    double y2;
    double z2;
    double x3;
    double y3;
    double z3;
    double x10;
    double y10;
    double x20;
    double y20;
    double x30;
    double y30;
    double x21;
    double y21;
    double x13;
    double y13;
    double x32;
    double y32;
    double tri1;
    double tri2;
    double tri3;
    double den;
    vector <double> distance(Lint1_cnt+Rint1_cnt+Lint2_cnt+Rint2_cnt);
    vector <int> closest(Lint1_cnt+Rint1_cnt+Lint2_cnt+Rint2_cnt);
    bool flag;
    int cnt_1=0;
    int cnt_2=0;
    count1=0;
    count2=0;

    // Loop over all species
    for (int k=0; k<nSpec; k++) {

      // Loop over all  molecules
      for (int i=0; i<nMols[k]; i++) {

	// Loop over all sites
	for (int j=0; j<nSites[k]; j++) {

	  if (Profile[k][j]==1) { // if we are calculating profile for this site

	    // Atom's positions
	    double x = Coords[k][i][j].X();
	    double y = Coords[k][i][j].Y();
	    double z = Coords[k][i][j].Z();
	    double oldZ = z;

	    // GLOBAL
	    // scale z by length of slab
	    oldZ /= lSlab; 
	    // determine slab in which atom is located
	    slice = int (oldZ);
	    // increment density
	    DensGl[k][j][slice]++;
	    // increment interfacial density
	    if (IntFlag1[k][i] || IntFlag2[k][i]) IntDensGl[k][j][slice]++;
      
	    // INTRINSIC (relative to phase 1)
	    // sort interfacial phase 1 molecules according to distance in xy plane
	    // loop over all interfacial phase 1 molecules
	    for (int jj=0; jj<Lint1_cnt; jj++) {
	      // calculate distances
	      double rx = phase1[Lint1_mol[jj]].X() - x;
	      if (rx>halfX) {
		rx -= boxX;
	      } else if (-rx>halfX) {
		rx += boxX;
	      }
	      double ry = phase1[Lint1_mol[jj]].Y() - y;
	      if (ry>halfY) {
		ry -= boxY;
	      } else if (-ry>halfY) {
		ry += boxY;
	      }
	      double rxy = rx*rx+ry*ry;

	      // find position of this molecule in rank
	      int kk;
	      for (kk=0; kk<jj; kk++) {
		if (rxy<distance[kk]) break;
	      }
	      // loop over all molecules below the present one
	      for (int kkk=jj; kkk>kk; kkk--) {
		distance[kkk]=distance[kkk-1]; // update distance vector
		closest[kkk]=closest[kkk-1]; // update molecule vector
	      }
	      distance[kk]=rxy;
	      closest[kk]=jj;
	    }

	    flag=false;

	    // interpolate distance between 3 closest molecules
	    // start with the two closest molecules (m1 and m2)
	    int i0=Lint1_mol[closest[0]];
	    int i1=Lint1_mol[closest[1]];
	    z1 = phase1[i0].Z();
	    x1 = phase1[i0].X();
	    y1 = phase1[i0].Y();
	    x2 = phase1[i1].X();
	    y2 = phase1[i1].Y();
	    z2 = phase1[i1].Z();
	    x21 = x2-x1;
	    y21 = y2-y1;
	    if (x21>halfX) {
	      x21 -= boxX;
	    } else if (-x21>halfX) {
	      x21 += boxX;
	    }
	    if (y21>halfY) {
	      y21 -= boxY;
	    } else if (-y21>halfY) {
	      y21 += boxY;
	    }
	    x10 = x1-x;
	    y10 = y1-y;
	    if (x10>halfX) {
	      x10 -= boxX;
	    } else if (-x10>halfX) {
	      x10 += boxX;
	    }
	    if (y10>halfY) {
	      y10 -= boxY;
	    } else if (-y10>halfY) {
	      y10 += boxY;
	    }
	    x20 = x2-x;
	    y20 = y2-y;
	    if (x20>halfX) {
	      x20 -= boxX;
	    } else if (-x20>halfX) {
	      x20 += boxX;
	    }
	    if (y20>halfY) {
	      y20 -= boxY;
	    } else if (-y20>halfY) {
	      y20 += boxY;
	    }
	    tri3 = x10*y21-y10*x21;

	    // now find third closest interfacial molecule (m3), provided that molecule i falls within 
	    //  the triangle formed by molecules m1, m2 and m3.
	    //  This ensures that an interpolation is done, and not an extrapolation!
	    for (int jj=2; jj<Lint1_cnt; jj++) {
	      int ij=Lint1_mol[closest[jj]];
	      x3 = phase1[ij].X();
	      y3 = phase1[ij].Y();
	      z3 = phase1[ij].Z();      
	      x13 = x1-x3;
	      y13 = y1-y3;
	      if (x13>halfX) {
		x13 -= boxX;
	      } else if (-x13>halfX) {
		x13 += boxX;
	      }
	      if (y13>halfY) {
		y13 -= boxY;
	      } else if (-y13>halfY) {
		y13 += boxY;
	      }
	      x32 = x3-x2;
	      y32 = y3-y2;
	      if (x32>halfX) {
		x32 -= boxX;
	      } else if (-x32>halfX) {
		x32 += boxX;
	      }
	      if (y32>halfY) {
		y32 -= boxY;
	      } else if (-y32>halfY) {
		y32 += boxY;
	      }
	      x30 = x3-x;
	      y30 = y3-y;
	      if (x30>halfX) {
		x30 -= boxX;
	      } else if (-x30>halfX) {
		x30 += boxX;
	      }
	      if (y30>halfY) {
		y30 -= boxY;
	      } else if (-y30>halfY) {
		y30 += boxY;
	      }
	      tri1 = x20*y32-y20*x32;
	      tri2 = x30*y13-y30*x13;
	      den = x21*y32-y21*x32;

	      // if the sum of the areas of the 3 minor triangles is equal to the area of the main triangle,
	      // then molecule i fits within the main triangle. Otherwise, keep looking for molecule m3.
	      if ((fabs(den)-fabs(tri1)-fabs(tri2)-fabs(tri3))==0) {
		flag=true; // triangle was found
		break;
	      }
	    }

	    if (den==0 || !flag) { // if the area of the triangle is zero or triangle was not found
	      cnt_2++;
	      interpol = z1; // don't interpolate, use Voronoi cell instead
	    } else {
	      interpol = (z1*tri1+z2*tri2+z3*tri3)/den; // interpolate distance
	    }

	    // shift z position by difference between intrinsic and average surfaces
	    double newZ = z - interpol + LAvgIntPos1;
	    // PBC
	    if (newZ>boxZ) {
	      newZ -= boxZ;
	    } else if (newZ<0.0) {
	      newZ += boxZ;
	    }

            if (IntFlag1[k][i] || IntFlag2[k][i]) dist_L1[k][i][j] = newZ; //z - interpol; // gyorgy2

	    // scale by length of slab
	    newZ /= lSlab; 
	    // determine slab in which atom is located
	    slice = int (newZ);
	    // increment intrinsic density
	    DensL1[k][j][slice]++;
	    // increment interfacial intrinsic density
	    if (IntFlag1[k][i] || IntFlag2[k][i]) IntDensL1[k][j][slice]++;

	    // Repeat for right interface
	    for (int jj=0; jj<Rint1_cnt; jj++) {
	      double rx = phase1[Rint1_mol[jj]].X() - x;
	      if (rx>halfX) {
		rx -= boxX;
	      } else if (-rx>halfX) {
		rx += boxX;
	      }
	      double ry = phase1[Rint1_mol[jj]].Y() - y;
	      if (ry>halfY) {
		ry -= boxY;
	      } else if (-ry>halfY) {
		ry += boxY;
	      }
	      double rxy = rx*rx+ry*ry;

	      // find position of this molecule in rank
	      int kk;
	      for (kk=0; kk<jj; kk++) {
		if (rxy<distance[kk]) break;
	      }
	      // loop over all molecules below the present one
	      for (int kkk=jj; kkk>kk; kkk--) {
		distance[kkk]=distance[kkk-1]; // update distance vector
		closest[kkk]=closest[kkk-1]; // update molecule vector
	      }
	      distance[kk]=rxy;
	      closest[kk]=jj;
	    }

	    flag=false;
	    i0=Rint1_mol[closest[0]];
	    i1=Rint1_mol[closest[1]];
	    z1 = phase1[i0].Z();
	    x1 = phase1[i0].X();
	    y1 = phase1[i0].Y();
	    x2 = phase1[i1].X();
	    y2 = phase1[i1].Y();
	    z2 = phase1[i1].Z();
	    x21 = x2-x1;
	    y21 = y2-y1;
	    if (x21>halfX) {
	      x21 -= boxX;
	    } else if (-x21>halfX) {
	      x21 += boxX;
	    }
	    if (y21>halfY) {
	      y21 -= boxY;
	    } else if (-y21>halfY) {
	      y21 += boxY;
	    }
	    x10 = x1-x;
	    y10 = y1-y;
	    if (x10>halfX) {
	      x10 -= boxX;
	    } else if (-x10>halfX) {
	      x10 += boxX;
	    }
	    if (y10>halfY) {
	      y10 -= boxY;
	    } else if (-y10>halfY) {
	      y10 += boxY;
	    }
	    x20 = x2-x;
	    y20 = y2-y;
	    if (x20>halfX) {
	      x20 -= boxX;
	    } else if (-x20>halfX) {
	      x20 += boxX;
	    }
	    if (y20>halfY) {
	      y20 -= boxY;
	    } else if (-y20>halfY) {
	      y20 += boxY;
	    }
	    tri3 = x10*y21-y10*x21;

	    for (int jj=2; jj<Rint1_cnt; jj++) {
	      int ij=Rint1_mol[closest[jj]];
	      x3 = phase1[ij].X();
	      y3 = phase1[ij].Y();
	      z3 = phase1[ij].Z();      
	      x13 = x1-x3;
	      y13 = y1-y3;
	      if (x13>halfX) {
		x13 -= boxX;
	      } else if (-x13>halfX) {
		x13 += boxX;
	      }
	      if (y13>halfY) {
		y13 -= boxY;
	      } else if (-y13>halfY) {
		y13 += boxY;
	      }
	      x32 = x3-x2;
	      y32 = y3-y2;
	      if (x32>halfX) {
		x32 -= boxX;
	      } else if (-x32>halfX) {
		x32 += boxX;
	      }
	      if (y32>halfY) {
		y32 -= boxY;
	      } else if (-y32>halfY) {
		y32 += boxY;
	      }
	      x30 = x3-x;
	      y30 = y3-y;
	      if (x30>halfX) {
		x30 -= boxX;
	      } else if (-x30>halfX) {
		x30 += boxX;
	      }
	      if (y30>halfY) {
		y30 -= boxY;
	      } else if (-y30>halfY) {
		y30 += boxY;
	      }
	      tri1 = x20*y32-y20*x32;
	      tri2 = x30*y13-y30*x13;
	      den = x21*y32-y21*x32;

	      if ((fabs(den)-fabs(tri1)-fabs(tri2)-fabs(tri3))==0) {
		flag=true;
		break;
	      }
	    }

	    if (den==0 || !flag) { 
	      cnt_2++;
	      interpol = z1; 
	    } else {
	      interpol = (z1*tri1+z2*tri2+z3*tri3)/den; 
	    }

	    newZ = z - interpol + RAvgIntPos1;
	    if (newZ>boxZ) {
	      newZ -= boxZ;
	    } else if (newZ<0.0) {
	      newZ += boxZ;
	    }

            if (IntFlag1[k][i] || IntFlag2[k][i]) dist_R1[k][i][j] = newZ; //z - interpol;

	    newZ /= lSlab; 
	    slice = int (newZ);
	    DensR1[k][j][slice]++;
	    if (IntFlag1[k][i] || IntFlag2[k][i]) IntDensR1[k][j][slice]++;

           if (!one_phase) { // do this only if we have two phases, gyorgy
	    // INTRINSIC (relative to phase2)
	    // sort interfacial phase2 molecules according to distance in xy plane
	    // loop over all interfacial phase2 molecules
	    for (int jj=0; jj<Lint2_cnt; jj++) {
	      // calculate distances
	      double rx = phase2[Lint2_mol[jj]].X() - x;
	      if (rx>halfX) {
		rx -= boxX;
	      } else if (-rx>halfX) {
		rx += boxX;
	      }
	      double ry = phase2[Lint2_mol[jj]].Y() - y;
	      if (ry>halfY) {
		ry -= boxY;
	      } else if (-ry>halfY) {
		ry += boxY;
	      }
	      double rxy = rx*rx+ry*ry;

	      // find position of this molecule in rank
	      int kk;
	      for (kk=0; kk<jj; kk++) {
		if (rxy<distance[kk]) break;
	      }
	      // loop over all molecules below the present one
	      for (int kkk=jj; kkk>kk; kkk--) {
		distance[kkk]=distance[kkk-1]; // update distance vector
		closest[kkk]=closest[kkk-1]; // update molecule vector
	      }
	      distance[kk]=rxy;
	      closest[kk]=jj;
	    }

	    flag=false;

	    // interpolate distance between 3 closest molecules
	    // start with the two closest molecules (m1 and m2)
	    i0=Lint2_mol[closest[0]];
	    i1=Lint2_mol[closest[1]];
	    z1 = phase2[i0].Z();
	    x1 = phase2[i0].X();
	    y1 = phase2[i0].Y();
	    x2 = phase2[i1].X();
	    y2 = phase2[i1].Y();
	    z2 = phase2[i1].Z();
	    x21 = x2-x1;
	    y21 = y2-y1;
	    if (x21>halfX) {
	      x21 -= boxX;
	    } else if (-x21>halfX) {
	      x21 += boxX;
	    }
	    if (y21>halfY) {
	      y21 -= boxY;
	    } else if (-y21>halfY) {
	      y21 += boxY;
	    }
	    x10 = x1-x;
	    y10 = y1-y;
	    if (x10>halfX) {
	      x10 -= boxX;
	    } else if (-x10>halfX) {
	      x10 += boxX;
	    }
	    if (y10>halfY) {
	      y10 -= boxY;
	    } else if (-y10>halfY) {
	      y10 += boxY;
	    }
	    x20 = x2-x;
	    y20 = y2-y;
	    if (x20>halfX) {
	      x20 -= boxX;
	    } else if (-x20>halfX) {
	      x20 += boxX;
	    }
	    if (y20>halfY) {
	      y20 -= boxY;
	    } else if (-y20>halfY) {
	      y20 += boxY;
	    }
	    tri3 = x10*y21-y10*x21;

	    // now find third closest interfacial molecule (m3), provided that molecule i falls within 
	    //  the triangle formed by molecules m1, m2 and m3.
	    //  This ensures that an interpolation is done, and not an extrapolation!
	    for (int jj=2; jj<Lint2_cnt; jj++) {
	      int ij=Lint2_mol[closest[jj]];
	      x3 = phase2[ij].X();
	      y3 = phase2[ij].Y();
	      z3 = phase2[ij].Z();      
	      x13 = x1-x3;
	      y13 = y1-y3;
	      if (x13>halfX) {
		x13 -= boxX;
	      } else if (-x13>halfX) {
		x13 += boxX;
	      }
	      if (y13>halfY) {
		y13 -= boxY;
	      } else if (-y13>halfY) {
		y13 += boxY;
	      }
	      x32 = x3-x2;
	      y32 = y3-y2;
	      if (x32>halfX) {
		x32 -= boxX;
	      } else if (-x32>halfX) {
		x32 += boxX;
	      }
	      if (y32>halfY) {
		y32 -= boxY;
	      } else if (-y32>halfY) {
		y32 += boxY;
	      }
	      x30 = x3-x;
	      y30 = y3-y;
	      if (x30>halfX) {
		x30 -= boxX;
	      } else if (-x30>halfX) {
		x30 += boxX;
	      }
	      if (y30>halfY) {
		y30 -= boxY;
	      } else if (-y30>halfY) {
		y30 += boxY;
	      }
	      tri1 = x20*y32-y20*x32;
	      tri2 = x30*y13-y30*x13;
	      den = x21*y32-y21*x32;

	      // if the sum of the areas of the 3 minor triangles is equal to the area of the main triangle,
	      // then molecule i fits within the main triangle. Otherwise, keep looking for molecule m3.
	      if ((fabs(den)-fabs(tri1)-fabs(tri2)-fabs(tri3))==0) {
		flag=true; // triangle was found
		break;
	      }
	    }

	    if (den==0 || !flag) { // if the area of the triangle is zero or triangle was not found
	      //cout << "WARNING " << distance[0] << endl;
	      cnt_2++;
	      interpol = z1; // don't interpolate, use Voronoi cell instead
	    } else {
	      interpol = (z1*tri1+z2*tri2+z3*tri3)/den; // interpolate distance
	    }

	    // shift z position by difference between intrinsic and average surfaces
	    newZ = z - interpol + LAvgIntPos2;
	    // PBC
	    if (newZ>boxZ) {
	      newZ -= boxZ;
	    } else if (newZ<0.0) {
	      newZ += boxZ;
	    }

	    // scale by length of slab
	    newZ /= lSlab; 
	    // determine slab in which atom is located
	    slice = int (newZ);
	    // increment intrinsic density
	    DensL2[k][j][slice]++;
	    // increment interfacial intrinsic density
	    if (IntFlag1[k][i] || IntFlag2[k][i]) IntDensL2[k][j][slice]++;

	    // Repeat for right interface
	    for (int jj=0; jj<Rint2_cnt; jj++) {
	      double rx = phase2[Rint2_mol[jj]].X() - x;
	      if (rx>halfX) {
		rx -= boxX;
	      } else if (-rx>halfX) {
		rx += boxX;
	      }
	      double ry = phase2[Rint2_mol[jj]].Y() - y;
	      if (ry>halfY) {
		ry -= boxY;
	      } else if (-ry>halfY) {
		ry += boxY;
	      }
	      double rxy = rx*rx+ry*ry;

	      int kk;
	      for (kk=0; kk<jj; kk++) {
		if (rxy<distance[kk]) break;
	      }
	      for (int kkk=jj; kkk>kk; kkk--) {
		distance[kkk]=distance[kkk-1]; // update distance vector
		closest[kkk]=closest[kkk-1]; // update molecule vector
	      }
	      distance[kk]=rxy;
	      closest[kk]=jj;
	    }

	    flag=false;
	    i0=Rint2_mol[closest[0]];
	    i1=Rint2_mol[closest[1]];
	    z1 = phase2[i0].Z();
	    x1 = phase2[i0].X();
	    y1 = phase2[i0].Y();
	    x2 = phase2[i1].X();
	    y2 = phase2[i1].Y();
	    z2 = phase2[i1].Z();
	    x21 = x2-x1;
	    y21 = y2-y1;
	    if (x21>halfX) {
	      x21 -= boxX;
	    } else if (-x21>halfX) {
	      x21 += boxX;
	    }
	    if (y21>halfY) {
	      y21 -= boxY;
	    } else if (-y21>halfY) {
	      y21 += boxY;
	    }
	    x10 = x1-x;
	    y10 = y1-y;
	    if (x10>halfX) {
	      x10 -= boxX;
	    } else if (-x10>halfX) {
	      x10 += boxX;
	    }
	    if (y10>halfY) {
	      y10 -= boxY;
	    } else if (-y10>halfY) {
	      y10 += boxY;
	    }
	    x20 = x2-x;
	    y20 = y2-y;
	    if (x20>halfX) {
	      x20 -= boxX;
	    } else if (-x20>halfX) {
	      x20 += boxX;
	    }
	    if (y20>halfY) {
	      y20 -= boxY;
	    } else if (-y20>halfY) {
	      y20 += boxY;
	    }
	    tri3 = x10*y21-y10*x21;

	    for (int jj=2; jj<Rint2_cnt; jj++) {
	      int ij=Rint2_mol[closest[jj]];
	      x3 = phase2[ij].X();
	      y3 = phase2[ij].Y();
	      z3 = phase2[ij].Z();      
	      x13 = x1-x3;
	      y13 = y1-y3;
	      if (x13>halfX) {
		x13 -= boxX;
	      } else if (-x13>halfX) {
		x13 += boxX;
	      }
	      if (y13>halfY) {
		y13 -= boxY;
	      } else if (-y13>halfY) {
		y13 += boxY;
	      }
	      x32 = x3-x2;
	      y32 = y3-y2;
	      if (x32>halfX) {
		x32 -= boxX;
	      } else if (-x32>halfX) {
		x32 += boxX;
	      }
	      if (y32>halfY) {
		y32 -= boxY;
	      } else if (-y32>halfY) {
		y32 += boxY;
	      }
	      x30 = x3-x;
	      y30 = y3-y;
	      if (x30>halfX) {
		x30 -= boxX;
	      } else if (-x30>halfX) {
		x30 += boxX;
	      }
	      if (y30>halfY) {
		y30 -= boxY;
	      } else if (-y30>halfY) {
		y30 += boxY;
	      }
	      tri1 = x20*y32-y20*x32;
	      tri2 = x30*y13-y30*x13;
	      den = x21*y32-y21*x32;

	      if ((fabs(den)-fabs(tri1)-fabs(tri2)-fabs(tri3))==0) {
		flag=true;
		break;
	      }
	    }

	    if (den==0 || !flag) { 
	      cnt_2++;
	      interpol = z1; 
	    } else {
	      interpol = (z1*tri1+z2*tri2+z3*tri3)/den; 
	    }

	    newZ = z - interpol + RAvgIntPos2;
	    if (newZ>boxZ) {
	      newZ -= boxZ;
	    } else if (newZ<0.0) {
	      newZ += boxZ;
	    }
	    newZ /= lSlab; 
	    slice = int (newZ);
	    DensR2[k][j][slice]++;
	    if (IntFlag1[k][i] || IntFlag2[k][i]) IntDensR2[k][j][slice]++;
           } // end of the calculation of intrinsic profiles according to phase2. gyorgy

	  }
	}
      }
    }

    // here we also output the distance of each site from the left and right interface of phase1: dist_L1[k][i][j] and dist_R1[k][i][j], gyorgy2
    for (int k=0;k<nSpec;k++) {
       // surface molecules
       for (int i=0; i<nMols[k]; i++) {
          if (IntFlag1[k][i] || IntFlag2[k][i]) {
              for (int j=0;j<nSites[k];j++) {
	        double dist_side;
	        if (dist_L1[k][i][j] < zMass1) {
	          dist_side = dist_L1[k][i][j];
	        } else {
	          dist_side = dist_R1[k][i][j];
	        }
                *(SurfSitesOut[k]) << Coords[k][i][j].X() << "\t" << Coords[k][i][j].Y() << "\t" << Coords[k][i][j].Z() << "\t" << dist_side << endl;
              }
          }
       }
       *(SurfSitesOut[k]) << endl;
    }



    nBlocks++;
    cout << nBlocks << endl;
    blc++;

    // PRINT PROPERTIES AT INTERMEDIATE STEPS (every hundred) 
    if ( nBlocks%10==0 ) {
    
      double conversionFactor=1.0/(1000*0.6022); // from uma nm-3 to g cm-3

      // open files   
      vector <ofstream *> DensGlOut(nSpec);
      vector <ofstream *> IntDensGlOut(nSpec);
      vector <ofstream *> DensL1Out(nSpec);
      vector <ofstream *> DensR1Out(nSpec);
      vector <ofstream *> DensL2Out(nSpec);
      vector <ofstream *> DensR2Out(nSpec);
      vector <ofstream *> IntDensL1Out(nSpec);
      vector <ofstream *> IntDensR1Out(nSpec);
      vector <ofstream *> IntDensL2Out(nSpec);
      vector <ofstream *> IntDensR2Out(nSpec);

      for (int k=0; k<nSpec; k++) { // loop over all species
	string fileName;
	ostringstream ostr;
	ostr << k+1;  
       
	fileName = "DensGl-sp" + ostr.str() + ".dat";
        DensGlOut[k] = new ofstream (fileName.c_str(), ios::out);
	DensGlOut[k]->setf(ios::fixed);		
	DensGlOut[k]->precision(8);		

	fileName = "IntDensGl-sp" + ostr.str() + ".dat";
        IntDensGlOut[k] = new ofstream (fileName.c_str(), ios::out);
	IntDensGlOut[k]->setf(ios::fixed);		
	IntDensGlOut[k]->precision(8);		

	fileName = "DensL1-sp" + ostr.str() + ".dat";
        DensL1Out[k] = new ofstream (fileName.c_str(), ios::out);
	DensL1Out[k]->setf(ios::fixed);		
	DensL1Out[k]->precision(8);		

	fileName = "DensR1-sp" + ostr.str() + ".dat";
        DensR1Out[k] = new ofstream (fileName.c_str(), ios::out);
	DensR1Out[k]->setf(ios::fixed);		
	DensR1Out[k]->precision(8);		

       //if (!one_phase) { // two-phase case. gyorgy
        fileName = "DensL2-sp" + ostr.str() + ".dat";
        DensL2Out[k] = new ofstream (fileName.c_str(), ios::out);
	DensL2Out[k]->setf(ios::fixed);		
	DensL2Out[k]->precision(8);		

	fileName = "DensR2-sp" + ostr.str() + ".dat";
        DensR2Out[k] = new ofstream (fileName.c_str(), ios::out);
	DensR2Out[k]->setf(ios::fixed);		
	DensR2Out[k]->precision(8);		
       //}

	fileName = "IntDensL1-sp" + ostr.str() + ".dat";
        IntDensL1Out[k] = new ofstream (fileName.c_str(), ios::out);
	IntDensL1Out[k]->setf(ios::fixed);		
	IntDensL1Out[k]->precision(8);		

	fileName = "IntDensR1-sp" + ostr.str() + ".dat";
        IntDensR1Out[k] = new ofstream (fileName.c_str(), ios::out);
	IntDensR1Out[k]->setf(ios::fixed);		
	IntDensR1Out[k]->precision(8);		

       //if (!one_phase) { // two-phase case. gyorgy
	fileName = "IntDensL2-sp" + ostr.str() + ".dat";
        IntDensL2Out[k] = new ofstream (fileName.c_str(), ios::out);
	IntDensL2Out[k]->setf(ios::fixed);		
	IntDensL2Out[k]->precision(8);		

	fileName = "IntDensR2-sp" + ostr.str() + ".dat";
        IntDensR2Out[k] = new ofstream (fileName.c_str(), ios::out);
	IntDensR2Out[k]->setf(ios::fixed);		
	IntDensR2Out[k]->precision(8);		
       //}

	// start printing properties

	// Headers
	*(DensGlOut[k]) << "# z(nm) ";
	*(IntDensGlOut[k]) << "# z(nm) ";
	*(DensL1Out[k]) << "# z(nm) ";
	*(DensR1Out[k]) << "# z(nm) ";
       if (!one_phase) { // two-phase case. gyorgy
	*(DensL2Out[k]) << "# z(nm) ";
	*(DensR2Out[k]) << "# z(nm) ";
       }
	*(IntDensL1Out[k]) << "# z(nm) ";
	*(IntDensR1Out[k]) << "# z(nm) ";
       if (!one_phase) { // two-phase case. gyorgy
	*(IntDensL2Out[k]) << "# z(nm) ";
	*(IntDensR2Out[k]) << "# z(nm) ";
       }
	for (int j=0; j<nSites[k]; j++) { // loop over all sites of each species
	  if (Profile[k][j]) {
	    *(DensGlOut[k]) << "Rho(" << j+1 << ") ";
	    *(IntDensGlOut[k]) << "Rho(" << j+1 << ") ";
	    *(DensL1Out[k]) << "Rho(" << j+1 << ") ";
	    *(DensR1Out[k]) << "Rho(" << j+1 << ") ";
	   if (!one_phase) { // two-phase case. gyorgy
	    *(DensL2Out[k]) << "Rho(" << j+1 << ") ";
	    *(DensR2Out[k]) << "Rho(" << j+1 << ") ";
	   }
	    *(IntDensL1Out[k]) << "Rho(" << j+1 << ") ";
	    *(IntDensR1Out[k]) << "Rho(" << j+1 << ") ";
	   if (!one_phase) { // two-phase case. gyorgy
	    *(IntDensL2Out[k]) << "Rho(" << j+1 << ") ";
	    *(IntDensR2Out[k]) << "Rho(" << j+1 << ") ";
	   }
	  }
	}
	*(DensGlOut[k]) << endl;
	*(IntDensGlOut[k]) << endl;
	*(DensL1Out[k]) << endl;
	*(DensR1Out[k]) << endl;
       if (!one_phase) { // two-phase case. gyorgy
	*(DensL2Out[k]) << endl;
	*(DensR2Out[k]) << endl;
       }
	*(IntDensL1Out[k]) << endl;
	*(IntDensR1Out[k]) << endl;
       if (!one_phase) { // two-phase case. gyorgy
	*(IntDensL2Out[k]) << endl;
	*(IntDensR2Out[k]) << endl;
       }

	// Densities
	for (int i=0; i<nSlabs; i++) { // loop over all slabs

	  // first column is z position (centre of each slab), shifted so that the origin is in the centre
	  *(DensGlOut[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	  *(IntDensGlOut[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	  *(DensL1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	  *(DensR1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	 if (!one_phase) { // two-phase case. gyorgy
	  *(DensL2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	  *(DensR2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	 }
	  *(IntDensL1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	  *(IntDensR1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	 if (!one_phase) { // two-phase case. gyorgy
	  *(IntDensL2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	  *(IntDensR2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
	 }

	  for (int j=0; j<nSites[k]; j++) { // loop over all sites of each species
	    if (Profile[k][j]) {
	      *(DensGlOut[k]) << DensGl[k][j][i]/nBlocks/slabVolume << "\t";
	      *(IntDensGlOut[k]) << IntDensGl[k][j][i]/nBlocks/slabVolume << "\t";
	      *(DensL1Out[k]) << DensL1[k][j][i]/nBlocks/slabVolume << "\t";
	      *(DensR1Out[k]) << DensR1[k][j][i]/nBlocks/slabVolume << "\t";
	     if (!one_phase) { // two-phase case. gyorgy
	      *(DensL2Out[k]) << DensL2[k][j][i]/nBlocks/slabVolume << "\t";
	      *(DensR2Out[k]) << DensR2[k][j][i]/nBlocks/slabVolume << "\t";
	     }
	      *(IntDensL1Out[k]) << IntDensL1[k][j][i]/nBlocks/slabVolume << "\t";
	      *(IntDensR1Out[k]) << IntDensR1[k][j][i]/nBlocks/slabVolume << "\t";
	     if (!one_phase) { // two-phase case. gyorgy
	      *(IntDensL2Out[k]) << IntDensL2[k][j][i]/nBlocks/slabVolume << "\t";
	      *(IntDensR2Out[k]) << IntDensR2[k][j][i]/nBlocks/slabVolume << "\t";
	     }
	    }
	  }
	  *(DensGlOut[k]) << endl;
	  *(IntDensGlOut[k]) << endl;
	  *(DensL1Out[k]) << endl;
	  *(DensR1Out[k]) << endl;
	 if (!one_phase) { // two-phase case. gyorgy
	  *(DensL2Out[k]) << endl;
	  *(DensR2Out[k]) << endl;
	 }
	  *(IntDensL1Out[k]) << endl;
	  *(IntDensR1Out[k]) << endl;
	 if (!one_phase) { // two-phase case. gyorgy
	  *(IntDensL2Out[k]) << endl;
	  *(IntDensR2Out[k]) << endl;
	 }
	}

        DensGlOut[k]->close();
        IntDensGlOut[k]->close();
        DensL1Out[k]->close();
        DensR1Out[k]->close();
       if (!one_phase) { // two-phase case. gyorgy
        DensL2Out[k]->close();
        DensR2Out[k]->close();
       }
        IntDensL1Out[k]->close();
        IntDensR1Out[k]->close();
       if (!one_phase) { // two-phase case. gyorgy
        IntDensL2Out[k]->close();
        IntDensR2Out[k]->close();
       }
      }

      cout << "Processed " << nBlocks << " blocks " << endl;		  

    }      
  }

  // PRINT PROPERTIES AT END OF FILE
  //  This enables use with unknown number of steps at the outset.
  
  double conversionFactor=1.0/(1000*0.6022); // from uma nm-3 to g cm-3

  // open files   
  vector <ofstream *> DensGlOut(nSpec);
  vector <ofstream *> IntDensGlOut(nSpec);
  vector <ofstream *> DensL1Out(nSpec);
  vector <ofstream *> DensR1Out(nSpec);
  vector <ofstream *> DensL2Out(nSpec);
  vector <ofstream *> DensR2Out(nSpec);
  vector <ofstream *> IntDensL1Out(nSpec);
  vector <ofstream *> IntDensR1Out(nSpec);
  vector <ofstream *> IntDensL2Out(nSpec);
  vector <ofstream *> IntDensR2Out(nSpec);

  for (int k=0; k<nSpec; k++) { // loop over all species
    string fileName;
    ostringstream ostr;
    ostr << k+1;  
       
    fileName = "DensGl-sp" + ostr.str() + ".dat";
    DensGlOut[k] = new ofstream (fileName.c_str(), ios::out);
    DensGlOut[k]->setf(ios::fixed);		
    DensGlOut[k]->precision(8);		

    fileName = "IntDensGl-sp" + ostr.str() + ".dat";
    IntDensGlOut[k] = new ofstream (fileName.c_str(), ios::out);
    IntDensGlOut[k]->setf(ios::fixed);		
    IntDensGlOut[k]->precision(8);		

    fileName = "DensL1-sp" + ostr.str() + ".dat";
    DensL1Out[k] = new ofstream (fileName.c_str(), ios::out);
    DensL1Out[k]->setf(ios::fixed);		
    DensL1Out[k]->precision(8);		

    fileName = "DensR1-sp" + ostr.str() + ".dat";
    DensR1Out[k] = new ofstream (fileName.c_str(), ios::out);
    DensR1Out[k]->setf(ios::fixed);		
    DensR1Out[k]->precision(8);		

   //if (!one_phase) { // two-phase case. gyorgy
    fileName = "DensL2-sp" + ostr.str() + ".dat";
    DensL2Out[k] = new ofstream (fileName.c_str(), ios::out);
    DensL2Out[k]->setf(ios::fixed);		
    DensL2Out[k]->precision(8);		

    fileName = "DensR2-sp" + ostr.str() + ".dat";
    DensR2Out[k] = new ofstream (fileName.c_str(), ios::out);
    DensR2Out[k]->setf(ios::fixed);		
    DensR2Out[k]->precision(8);		
   //}

    fileName = "IntDensL1-sp" + ostr.str() + ".dat";
    IntDensL1Out[k] = new ofstream (fileName.c_str(), ios::out);
    IntDensL1Out[k]->setf(ios::fixed);		
    IntDensL1Out[k]->precision(8);		

    fileName = "IntDensR1-sp" + ostr.str() + ".dat";
    IntDensR1Out[k] = new ofstream (fileName.c_str(), ios::out);
    IntDensR1Out[k]->setf(ios::fixed);		
    IntDensR1Out[k]->precision(8);		

   //if (!one_phase) { // two-phase case. gyorgy
    fileName = "IntDensL2-sp" + ostr.str() + ".dat";
    IntDensL2Out[k] = new ofstream (fileName.c_str(), ios::out);
    IntDensL2Out[k]->setf(ios::fixed);		
    IntDensL2Out[k]->precision(8);		

    fileName = "IntDensR2-sp" + ostr.str() + ".dat";
    IntDensR2Out[k] = new ofstream (fileName.c_str(), ios::out);
    IntDensR2Out[k]->setf(ios::fixed);		
    IntDensR2Out[k]->precision(8);		
   //}

    // start printing properties

    // Headers
    *(DensGlOut[k]) << "# z(nm) ";
    *(IntDensGlOut[k]) << "# z(nm) ";
    *(DensL1Out[k]) << "# z(nm) ";
    *(DensR1Out[k]) << "# z(nm) ";
   if (!one_phase) { // two-phase case. gyorgy
    *(DensL2Out[k]) << "# z(nm) ";
    *(DensR2Out[k]) << "# z(nm) ";
   }
    *(IntDensL1Out[k]) << "# z(nm) ";
    *(IntDensR1Out[k]) << "# z(nm) ";
   if (!one_phase) { // two-phase case. gyorgy
    *(IntDensL2Out[k]) << "# z(nm) ";
    *(IntDensR2Out[k]) << "# z(nm) ";
   }
    for (int j=0; j<nSites[k]; j++) { // loop over all sites of each species
      if (Profile[k][j]) {
	*(DensGlOut[k]) << "Rho(" << j+1 << ") ";
	*(IntDensGlOut[k]) << "Rho(" << j+1 << ") ";
	*(DensL1Out[k]) << "Rho(" << j+1 << ") ";
	*(DensR1Out[k]) << "Rho(" << j+1 << ") ";
       if (!one_phase) { // two-phase case. gyorgy
	*(DensL2Out[k]) << "Rho(" << j+1 << ") ";
	*(DensR2Out[k]) << "Rho(" << j+1 << ") ";
       }
	*(IntDensL1Out[k]) << "Rho(" << j+1 << ") ";
	*(IntDensR1Out[k]) << "Rho(" << j+1 << ") ";
       if (!one_phase) { // two-phase case. gyorgy
	*(IntDensL2Out[k]) << "Rho(" << j+1 << ") ";
	*(IntDensR2Out[k]) << "Rho(" << j+1 << ") ";
       }
      }
    }
    *(DensGlOut[k]) << endl;
    *(IntDensGlOut[k]) << endl;
    *(DensL1Out[k]) << endl;
    *(DensR1Out[k]) << endl;
   if (!one_phase) { // two-phase case. gyorgy
    *(DensL2Out[k]) << endl;
    *(DensR2Out[k]) << endl;
   }
    *(IntDensL1Out[k]) << endl;
    *(IntDensR1Out[k]) << endl;
   if (!one_phase) { // two-phase case. gyorgy
    *(IntDensL2Out[k]) << endl;
    *(IntDensR2Out[k]) << endl;
   }

    // Densities
    for (int i=0; i<nSlabs; i++) { // loop over all slabs

      // first column is z position (centre of each slab), shifted so that the origin is in the centre
      *(DensGlOut[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
      *(IntDensGlOut[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
      *(DensL1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
      *(DensR1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
     if (!one_phase) { // two-phase case. gyorgy
      *(DensL2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
      *(DensR2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
     }
      *(IntDensL1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
      *(IntDensR1Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
     if (!one_phase) { // two-phase case. gyorgy
      *(IntDensL2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
      *(IntDensR2Out[k]) << (i+0.5-0.5*nSlabs)*lSlabPpt.average() << "\t";
     }

      for (int j=0; j<nSites[k]; j++) { // loop over all sites of each species
	if (Profile[k][j]) {
	  *(DensGlOut[k]) << DensGl[k][j][i]/nBlocks/slabVolume << "\t";
	  *(IntDensGlOut[k]) << IntDensGl[k][j][i]/nBlocks/slabVolume << "\t";
	  *(DensL1Out[k]) << DensL1[k][j][i]/nBlocks/slabVolume << "\t";
	  *(DensR1Out[k]) << DensR1[k][j][i]/nBlocks/slabVolume << "\t";
	 if (!one_phase) { // two-phase case. gyorgy
	  *(DensL2Out[k]) << DensL2[k][j][i]/nBlocks/slabVolume << "\t";
	  *(DensR2Out[k]) << DensR2[k][j][i]/nBlocks/slabVolume << "\t";
	 }
	  *(IntDensL1Out[k]) << IntDensL1[k][j][i]/nBlocks/slabVolume << "\t";
	  *(IntDensR1Out[k]) << IntDensR1[k][j][i]/nBlocks/slabVolume << "\t";
	 if (!one_phase) { // two-phase case. gyorgy
	  *(IntDensL2Out[k]) << IntDensL2[k][j][i]/nBlocks/slabVolume << "\t";
	  *(IntDensR2Out[k]) << IntDensR2[k][j][i]/nBlocks/slabVolume << "\t";
	 }
	}
      }
      *(DensGlOut[k]) << endl;
      *(IntDensGlOut[k]) << endl;
      *(DensL1Out[k]) << endl;
      *(DensR1Out[k]) << endl;
     if (!one_phase) { // two-phase case. gyorgy
      *(DensL2Out[k]) << endl;
      *(DensR2Out[k]) << endl;
     }
      *(IntDensL1Out[k]) << endl;
      *(IntDensR1Out[k]) << endl;
     if (!one_phase) { // two-phase case. gyorgy
      *(IntDensL2Out[k]) << endl;
      *(IntDensR2Out[k]) << endl;
     }
    }

    DensGlOut[k]->close();
    IntDensGlOut[k]->close();
    DensL1Out[k]->close();
    DensR1Out[k]->close();
   if (!one_phase) { // two-phase case. gyorgy
    DensL2Out[k]->close();
    DensR2Out[k]->close();
   }
    IntDensL1Out[k]->close();
    IntDensR1Out[k]->close();
   if (!one_phase) { // two-phase case. gyorgy
    IntDensL2Out[k]->close();
    IntDensR2Out[k]->close();
   }
    SurfSitesOut[k]->close();
  }

  cout << "Processed " << nBlocks << " blocks " << endl;		  

  return (EXIT_SUCCESS);

}
