//										0.2.1

// %Z%
// %M% %I%
// Autor Pedro C Reis Rodrigues

#ifndef VECTORXYZ_H
#define VECTORXYZ_H

#include <iostream>

#include <float.h>

#define min(a,b) ((a) <= (b) ? (a) : (b))
#define max(a,b) ((a) >= (b) ? (a) : (b))

using namespace std;
 
class Vector  {

    protected:

      double	x, y, z;

    public:

inline	Vector() { x = y = z = 0; }
inline	Vector( double, double, double );
inline	Vector( double f ) { x = y = z = f; }

friend	Vector operator+( const Vector, const Vector );
friend	Vector operator-( const Vector, const Vector );
friend	Vector operator*( const Vector, const double );
friend	Vector operator*( const double, const Vector );
friend	Vector operator/( const Vector, const double );
friend	double operator*( const Vector, const Vector );
friend	Vector operator+=( Vector&, const Vector );
friend	Vector operator-=( Vector&, const Vector );
friend	Vector  operator*=( Vector&, const double );
friend	Vector  operator/=( Vector&, const double );

friend Vector operator^ (const Vector, const Vector);

double modulus() { return sqrt(x * x + y * y + z * z); }

void	print() { cout << "(" << x << "," << y << "," << z << ")\n"; }

double X() {return x;};	//NOVO
double Y() {return y;};	//NOVO
double Z() {return z;};	//NOVO

};

inline
Vector::Vector( double xx, double yy, double zz )
{
    x = xx;
    y = yy;
    z = zz;
}


inline
Vector operator+( register const Vector v1, register const Vector v2 )
{
    return Vector( v1.x + v2.x, v1.y + v2.y, v1.z + v2.z );
}

inline
Vector operator-( register const Vector v1, register const Vector v2 )
{
    return Vector( v1.x - v2.x, v1.y - v2.y, v1.z - v2.z );
}

inline
double operator*( register const Vector v1, register const Vector v2 )
{
    return ( v1.x * v2.x + v1.y * v2.y + v1.z * v2.z );
}

inline
Vector operator*( register const Vector v, register const double f )
{
    return Vector( v.x * f, v.y * f, v.z * f );
}

inline
Vector operator*( register const double f, register const Vector v )
{
    return Vector( v.x * f, v.y * f, v.z * f );
}

inline
Vector operator/( const Vector v1, const double f2 )
{
    return Vector( v1.x / f2, v1.y / f2, v1.z / f2 );
}


inline
Vector operator+=( Vector& v1, const Vector v2 )
{
    return (v1 = v1 + v2);
}

inline
Vector operator-=( Vector& v1, const Vector v2 )
{
    return (v1 = v1 - v2);
}

inline
Vector  operator*=( Vector& v, const double f )
{
    return (v = v * f);
}

inline
Vector  operator/=( Vector& v, const double f )
{
    return (v = v / f);
}

inline
Vector operator^ ( register const Vector v1, register const Vector v2 )
{
    return Vector( v1.y * v2.z - v1.z * v2.y, v1.z * v2.x - v1.x * v2.z, v1.x * v2.y - v1.y * v2.x );
}




class Box {

	double	Rcut;

    public:
    	
    	Box() { }
	virtual double	maxCutOff()=0;
	void setCutOff( double cut ) { Rcut = min( cut, maxCutOff() ); }
	double RCut() { return Rcut; }
	virtual void		setBounds(double, double, double)=0;
	virtual void		setBounds( double ) = 0;
	virtual double 	boundedX( const double x, const double y, const double z  )=0;
	virtual double 	boundedY( const double x, const double y, const double z  )=0;
	virtual double 	boundedZ( const double x, const double y, const double z  )=0;	
};

class None: public Box {

    public:

	double maxCutOff() { return FLT_MAX; }
	void setBounds (double x, double y, double z) {}
	void setBounds (double x) {}
	double boundedX( const double x, const double y, const double z ) 	{ return x; }
	double boundedY( const double x, const double y, const double z )	{ return y; }
	double boundedZ( const double x, const double y, const double z )	{ return z; }

};



class Parallel : public Box {
	double Lx, Ly, Lz;
	double Lx2, Ly2,Lz2;
	
    public:
    
	Parallel( double x ) { setBounds( x ); }
	Parallel( double x, double y, double z ) { setBounds( x, y, z ); }
	double maxCutOff() { return ( min( min(Lx,Ly) ,Lz ) / 2 ); }
	void setBounds (double x, double y, double z) { Lx2=(Lx=x)/2; Ly2=(Ly=y)/2; Lz2=(Lz=z)/2; }
	void setBounds (double x) { setBounds ( x,  x,  x ); }				//cubic
	inline
	double bounded( const double x, const double lx2, const double lx );
	double boundedX( const double x, const double y, const double z ) { return bounded (x, Lx2, Lx); }
	double boundedY( const double x, const double y, const double z )	{ return bounded (y, Ly2, Ly); }
	double boundedZ( const double x, const double y, const double z )	{ return bounded (z, Lz2, Lz); }
};

inline
double	Parallel::bounded( const double x, const double lx2, const double lx )
    {
    double bx = x;
    
    if ( bx > lx2 )
	bx = bx - lx;
    else
	{
	if ( bx < -lx2 )
	    bx = bx + lx;
	}
    return bx;
    }

class BoundedVector : public Vector {

    private:
    
	static Box* box;
	
    public:

	BoundedVector() : Vector() { }
  BoundedVector( double x, double y, double z ) : Vector( x, y , z ) { (*this) = BoundedVector( *this );  }
			
	BoundedVector( Vector v ) : Vector( v ) {
	    x = box->boundedX(x,y,z); y = box->boundedY(x,y,z); z = box->boundedZ(x,y,z); }
	void	setBounds( double x ) { box->setBounds( x ); }
	void	setBounds( double x, double y, double z ) { box->setBounds( x, y , z ); }

  double maxCutOff() {return box->maxCutOff(); }
	
};



#endif









