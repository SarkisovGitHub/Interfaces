#!/usr/bin/perl
#***************************************************************************
#    xtc.pl- parses xtc files from STDIN to STDOUT
#
#                             -------------------
#    begin                : Sat Apr 16 2005
#    copyright            : (C) 2005 by Daniel dos Santos
#    email                : dos.santos.daniel@gmail.com
# ***************************************************************************/

#/***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General Public License as published by  *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************/

if ( $#ARGV == 7) {
        $nSp1Mols = $ARGV[0];
        $nSp1Sites = $ARGV[1];
        $nSp2Mols = $ARGV[2];
        $nSp2Sites = $ARGV[3];
		$nSp3Mols = $ARGV[4];
		$nSp3Sites = $ARGV[5];
		$nSp4Mols = $ARGV[6];
		$nSp4Sites = $ARGV[7];
} else {
        die "usage: $0 n_molecules_of_sp1 n_sites_of_sp1 n_molecules_of_sp2 n_sites_of_sp2 n_molecules_of_sp3 n_sites_of_sp3 n_molecules_of_sp4 n_sites_of_sp4 \n";
}

@line;
@line1;


while ( <STDIN> ) {
	
	$_=<STDIN>;
	@line = split;
	$nAtoms=$line[1];
	$time=$line[5];

	print $nAtoms."\n";	
	#print $time."\n";	

	$_=<STDIN>;
	
	$_=<STDIN>;	
	@line = split;
	$xBox = $line[2];
	
	print substr($xBox, 0, -1)."\t";
	
	$_=<STDIN>;	
	@line = split;
	$yBox = $line[3];
	print substr($yBox, 0, -1)."\t";	
	
	$_=<STDIN>;	
	@line = split;
	$zBox = $line[4];
	print substr($zBox, 0, -1)."\n";	

	$_=<STDIN>;		
	
        #print "0 \n";  
        print $nSp1Mols."\n";
	
	for ($i=0; $i<$nAtoms;  $i++) {

                if ($i==$nSp1Mols*$nSp1Sites) {
                    print "0 \n";
                    print $nSp2Mols."\n";
                }
				
				if ($i==($nSp1Mols*$nSp1Sites+$nSp2Mols*$nSp2Sites)) {
                    print "0 \n";
					print "0 \n";
                    print $nSp3Mols."\n";
				}
				if ($i==($nSp1Mols*$nSp1Sites+$nSp2Mols*$nSp2Sites+$nSp3Mols*$nSp3Sites)) {
                    print "0 \n";
                    print $nSp4Mols."\n";
				}
	
		$_=<STDIN>;	
		@line = split("{", $_);	
		@line1= split(" ", $line[1]);
							
		$x=substr($line1[0], 0, -1);
		$y=substr($line1[1], 0, -1);
		$z=substr($line1[2], 0, -1);
				
		print $x."\t".$y."\t".$z."\n";
	}

        #print "0 \n";

}
