The present code carries out an intrinsic analysis of planar liquid-liquid interfaces. It uses the ITIM method 
(Partay et al, J. Comp. Chem., 2008, 29:945) to find the true set of interfacial sites, then applies triangular
interpolation (Jorge et al., J. Phys. Chem. C, submitted) to approximate the surface for the calculation of
intrinsic profiles. It is assumed that the z coordinate is normal to the interfacial plane.

1 step - compilation of files (folder ITIM_code)

c++ itim5.C -o itim5

2 step - run (folder with trajectory)
The code can be run starting from an input data file with atomic coordinates or directly from the MD trajectory, as follows:

gmx_mpi dump -f traj_comp.xtc | ./xtc.pl n_molecules_of_sp1 (500) n_sites_of_sp1 (25) n_molecules_of_sp2 (500) n_sites_of_sp2 (7) | ./ITIM_Interpol - param_file (param.inp) nsteps (0-...)

The file xtc.pl is a script to convert the gromacs trajectory to an appropriate format for use by the code.

The first step is to read the parameters and the input data. The simulation may contain any number of different
species. Each species contains a given number of molecules, each composed of a given number of sites. For the
analysis, the system is divided into two distinct phases, and each species is assigned to a given phase. The set
of interfacial molecules is then searched in the entire phase, while profiles are calculated separately for each species.


Details of the parameter file (strict format):


#GENERAL INFORMATION (DENSITY PROFILE INFORMATION)
282 # number of slabs in the Z direction for the calculation of profiles, optimum spacing is 0.04 nm (box length in Z direction / 0.04)
2 # total number of species in the system (this must match the number of species in the MD trajectory) (example: BMIM and PF6)

#ITIM PARAMETERS (INTERFACE PARAMETERS)
112 # number of test lines (grid in X,Y) of ITIM method for phase 1 (phase 1 is positioned at the center of the box), optimum spacing is 0.05 nm (box length in X or Y / 0.05)
0.2 # probe sphere radius of ITIM method for phase 1 (depends on molecular size, sensitivity can be tested with the sphere radius 0.18-0.22)
112 # number of test lines (grid in X,Y) of ITIM method for phase 2 (phase 2 is positioned at the edges of the box), optimum spacing is 0.05 nm (box length in X or Y / 0.05) 
0.125 # probe sphere radius of ITIM method for phase 2 (depends on molecular size)

#SPECIES DATA (repeat this block for each species)
500 # total number of molecules of species i (example 500 molecules of BMIM)
25 # number of sites on each molecule of species i (example 25 atoms in BMIM)
14.007 0.176  0.325    0.711280 1 #data for each site: mass (g/mol), charge (a.u.), sigma (nm), epsilon (kJ/mol), profile (0 or 1)
14.007 0.176  0.325    0.711280 1
12.011 -0.072 0.355    0.292880 1
1.008  0.168  0.242    0.125520 1
12.011 -0.192 0.355    0.292880 1
1.008  0.216  0.242    0.125520 1
12.011 -0.192 0.355    0.292880 1
1.008  0.216  0.242    0.125520 1
12.011 -0.28  0.350    0.276144 1
1.008  0.144  0.250    0.125520 1
1.008  0.144  0.250    0.125520 1
1.008  0.144  0.250    0.125520 1
12.011 -0.136 0.350    0.276144 1
1.008  0.144  0.250    0.125520 1
1.008  0.144  0.250    0.125520 1
12.011 -0.096 0.350    0.276144 1
1.008  0.048  0.250    0.125520 1
1.008  0.048  0.250    0.125520 1
12.011 -0.096 0.350    0.276144 1
1.008  0.048  0.250    0.125520 1
1.008  0.048  0.250    0.125520 1
12.011 -0.192 0.350    0.276144 1
1.008  0.064  0.250    0.125520 1
1.008  0.064  0.250    0.125520 1
1.008  0.064  0.250    0.125520 1

500 
7 #number of sites on each molecule of species i (example 7 atoms in PF6)
30.974  1.072 0.37400 0.83700 1
18.998 -0.312 0.31181 0.25522 1
18.998 -0.312 0.31181 0.25522 1
18.998 -0.312 0.31181 0.25522 1
18.998 -0.312 0.31181 0.25522 1
18.998 -0.312 0.31181 0.25522 1
18.998 -0.312 0.31181 0.25522 1

#A site with sigma = 0.0 is not included in the search for interfacial sites
#Variable profile (0 or 1) determines if a density profile is (1) or not (0) calculated for this site
