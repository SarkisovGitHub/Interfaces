#$ -N IL
#$ -cwd                  
#$ -pe sharedmem 16
#$ -l h_rt=48:00:00 
#$ -l h_vmem=4G

# Initialise the environment modules
. /etc/profile.d/modules.sh 
module load eng/gromacs
export LD_LIBRARY_PATH=/usr/lib64/

gmx_mpi grompp -f en_min.mdp -c BMIMPF6.gro -p BMIMPF6.top -o en_min.tpr

gmx_mpi mdrun -v -s en_min.tpr -ntomp 16 -c BMIMPF6_en_min.gro

gmx_mpi grompp -f eq_nvt.mdp -c BMIMPF6_en_min.gro -p BMIMPF6.top -o eq_nvt.tpr

gmx_mpi mdrun -v -s eq_nvt.tpr -ntomp 16 -c BMIMPF6_eq_nvt.gro

gmx_mpi grompp -f eq_npt.mdp -c BMIMPF6_eq_nvt.gro -p BMIMPF6.top -o eq_npt.tpr

gmx_mpi mdrun -v -s eq_npt.tpr -ntomp 16 -c BMIMPF6_eq_npt.gro

gmx_mpi grompp -f md_sim.mdp -c BMIMPF6_eq_npt.gro -p BMIMPF6.top -o md_sim.tpr

gmx_mpi mdrun -v -s md_sim.tpr -ntomp 16 -c BMIMPF6_md_sim.gro