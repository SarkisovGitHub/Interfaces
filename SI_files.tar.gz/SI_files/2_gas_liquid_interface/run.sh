#$ -N IL_CO2N2
#$ -cwd                  
#$ -pe sharedmem 8
#$ -l h_rt=47:00:00 
#$ -l h_vmem=4G

# Initialise the environment modules
. /etc/profile.d/modules.sh 
module load eng/gromacs
export LD_LIBRARY_PATH=/usr/lib64/

gmx_mpi grompp -f en_min.mdp -c BMIMPF6_CO2_N2_500_100_100.gro -p BMIMPF6_CO2_N2.top -o en_min.tpr

gmx_mpi mdrun -v -s en_min.tpr -ntomp 8 -c BMIMPF6_CO2_N2_en_min.gro

gmx_mpi grompp -f eq_nvt.mdp -c BMIMPF6_CO2_N2_en_min.gro -p BMIMPF6_CO2_N2.top -o eq_nvt.tpr

gmx_mpi mdrun -v -s eq_nvt.tpr -ntomp 8 -c BMIMPF6_CO2_N2_eq_nvt.gro

gmx_mpi grompp -f md_sim.mdp -c BMIMPF6_CO2_N2_eq_nvt.gro -p BMIMPF6_CO2_N2.top -o md_sim.tpr

gmx_mpi mdrun -v -s md_sim.tpr -ntomp 8 -c BMIMPF6_CO2_N2_md_sim.gro